import { sql } from "drizzle-orm";
import {
  boolean,
  date,
  integer,
  jsonb,
  numeric,
  pgTable,
  real,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// =========================
// Existing
// =========================
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// =========================
// Digital Twin: Climate-Smart Farming
// =========================

export const dtRegions = pgTable("dt_regions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  // Optional geometry (GeoJSON) if you want region polygons later
  geom: jsonb("geom"),
});

export const dtFields = pgTable("dt_fields", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  regionId: varchar("region_id")
    .notNull()
    .references(() => dtRegions.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  commodity: text("commodity").notNull(),
  // GeoJSON Polygon/MultiPolygon
  geom: jsonb("geom").notNull(),
  // GeoJSON Point
  centroid: jsonb("centroid").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const dtFieldMetrics = pgTable("dt_field_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fieldId: varchar("field_id")
    .notNull()
    .references(() => dtFields.id, { onDelete: "cascade" }),
  date: date("date").notNull(),
  ndvi: real("ndvi"),
  rainfallMm: real("rainfall_mm"),
  tempC: real("temp_c"),
  waterStressIdx: real("water_stress_idx"),
  floodRiskIdx: real("flood_risk_idx"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const dtAlerts = pgTable("dt_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fieldId: varchar("field_id").references(() => dtFields.id, {
    onDelete: "set null",
  }),
  regionId: varchar("region_id").references(() => dtRegions.id, {
    onDelete: "set null",
  }),
  type: text("type").notNull(),
  severity: text("severity").notNull(),
  message: text("message").notNull(),
  occurredAt: timestamp("occurred_at").notNull(),
  payload: jsonb("payload").notNull().default({}),
});

// Insert schemas
export const insertDtRegionSchema = createInsertSchema(dtRegions).omit({
  id: true,
});

export const insertDtFieldSchema = createInsertSchema(dtFields).omit({
  id: true,
  createdAt: true,
});

export const insertDtFieldMetricSchema = createInsertSchema(dtFieldMetrics).omit({
  id: true,
  createdAt: true,
});

export const insertDtAlertSchema = createInsertSchema(dtAlerts).omit({
  id: true,
});

// Base types
export type DtRegion = typeof dtRegions.$inferSelect;
export type InsertDtRegion = z.infer<typeof insertDtRegionSchema>;

export type DtField = typeof dtFields.$inferSelect;
export type InsertDtField = z.infer<typeof insertDtFieldSchema>;

export type DtFieldMetric = typeof dtFieldMetrics.$inferSelect;
export type InsertDtFieldMetric = z.infer<typeof insertDtFieldMetricSchema>;

export type DtAlert = typeof dtAlerts.$inferSelect;
export type InsertDtAlert = z.infer<typeof insertDtAlertSchema>;

// =========================
// API contract types (explicit)
// =========================

export type DateRange = "7d" | "30d" | "90d";
export type DtLayer =
  | "ndvi"
  | "rainfall_anom"
  | "temp_anom"
  | "flood_risk"
  | "water_stress";

export type AlertSeverity = "low" | "medium" | "high" | "critical";

export type DtSummaryResponse = {
  kpis: {
    cropHealthScore: number;
    climateRiskIndex: number;
    waterStressPct: number;
    floodWatchCount: number;
    yieldForecast?: number | null;
  };
  trends: {
    cropHealthDeltaPct: number;
    climateRiskDeltaPct: number;
    waterStressDeltaPct: number;
    floodWatchDeltaPct: number;
    yieldForecastDeltaPct?: number | null;
  };
  stats: {
    fieldsCount: number;
    regionsCount: number;
    stressedFieldsCount: number;
    highRiskFieldsCount: number;
  };
};

export type DtFieldsGeoJson = {
  type: "FeatureCollection";
  features: Array<{
    type: "Feature";
    id: string;
    geometry: any;
    properties: {
      id: string;
      name: string;
      regionId: string;
      commodity: string;
      latestNdvi?: number | null;
      waterStressIdx?: number | null;
      floodRiskIdx?: number | null;
    };
  }>;
};

export type DtFieldMetricsResponse = {
  field: {
    id: string;
    name: string;
    regionId: string;
    commodity: string;
  };
  series: Array<{
    date: string;
    ndvi: number | null;
    rainfallMm: number | null;
    tempC: number | null;
    waterStressIdx: number | null;
    floodRiskIdx: number | null;
    rainfallAnom?: number | null;
    tempAnom?: number | null;
    riskScore: number;
  }>;
  summary: {
    ndviAvg: number | null;
    rainfallTotalMm: number | null;
    tempAvgC: number | null;
    waterStressMax: number | null;
    floodRiskMax: number | null;
    currentRiskBadges: Array<{
      type: string;
      severity: AlertSeverity;
      label: string;
    }>;
  };
};

export type DtAlertItem = {
  id: string;
  fieldId?: string | null;
  regionId?: string | null;
  type: string;
  severity: AlertSeverity;
  message: string;
  occurredAt: string;
  payload: Record<string, unknown>;
};

export type DtAlertsResponse = {
  items: DtAlertItem[];
};

export const WS_CHANNELS = {
  dtAlerts: "dt-alerts",
} as const;

export type DtAlertsWsMessage =
  | { type: "hello"; channel: typeof WS_CHANNELS.dtAlerts }
  | { type: "alert"; channel: typeof WS_CHANNELS.dtAlerts; payload: DtAlertItem }
  | {
      type: "alerts";
      channel: typeof WS_CHANNELS.dtAlerts;
      payload: { items: DtAlertItem[] };
    };
