import { z } from "zod";
import {
  insertDtAlertSchema,
  insertDtFieldMetricSchema,
  insertDtFieldSchema,
  insertDtRegionSchema,
} from "@shared/schema";

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

const dateRangeSchema = z.enum(["7d", "30d", "90d"]);
const layerSchema = z.enum([
  "ndvi",
  "rainfall_anom",
  "temp_anom",
  "flood_risk",
  "water_stress",
]);

export const api = {
  digitalTwinClimateSmart: {
    summary: {
      method: "GET" as const,
      path: "/api/digital-twin/climate-smart/summary" as const,
      input: z
        .object({
          dateRange: dateRangeSchema.default("30d"),
          regionId: z.string().optional(),
          commodity: z.string().optional(),
        })
        .optional(),
      responses: {
        200: z.object({
          kpis: z.object({
            cropHealthScore: z.number(),
            climateRiskIndex: z.number(),
            waterStressPct: z.number(),
            floodWatchCount: z.number(),
            yieldForecast: z.number().nullable().optional(),
          }),
          trends: z.object({
            cropHealthDeltaPct: z.number(),
            climateRiskDeltaPct: z.number(),
            waterStressDeltaPct: z.number(),
            floodWatchDeltaPct: z.number(),
            yieldForecastDeltaPct: z.number().nullable().optional(),
          }),
          stats: z.object({
            fieldsCount: z.number(),
            regionsCount: z.number(),
            stressedFieldsCount: z.number(),
            highRiskFieldsCount: z.number(),
          }),
        }),
      },
    },
    fields: {
      method: "GET" as const,
      path: "/api/digital-twin/climate-smart/fields" as const,
      input: z
        .object({
          regionId: z.string().optional(),
          commodity: z.string().optional(),
        })
        .optional(),
      responses: {
        200: z.object({
          type: z.literal("FeatureCollection"),
          features: z.array(
            z.object({
              type: z.literal("Feature"),
              id: z.string(),
              geometry: z.any(),
              properties: z.object({
                id: z.string(),
                name: z.string(),
                regionId: z.string(),
                commodity: z.string(),
                latestNdvi: z.number().nullable().optional(),
                waterStressIdx: z.number().nullable().optional(),
                floodRiskIdx: z.number().nullable().optional(),
              }),
            }),
          ),
        }),
      },
    },
    fieldMetrics: {
      method: "GET" as const,
      path: "/api/digital-twin/climate-smart/fields/:id/metrics" as const,
      input: z
        .object({
          dateRange: dateRangeSchema.default("30d"),
        })
        .optional(),
      responses: {
        200: z.object({
          field: z.object({
            id: z.string(),
            name: z.string(),
            regionId: z.string(),
            commodity: z.string(),
          }),
          series: z.array(
            z.object({
              date: z.string(),
              ndvi: z.number().nullable(),
              rainfallMm: z.number().nullable(),
              tempC: z.number().nullable(),
              waterStressIdx: z.number().nullable(),
              floodRiskIdx: z.number().nullable(),
              rainfallAnom: z.number().nullable().optional(),
              tempAnom: z.number().nullable().optional(),
              riskScore: z.number(),
            }),
          ),
          summary: z.object({
            ndviAvg: z.number().nullable(),
            rainfallTotalMm: z.number().nullable(),
            tempAvgC: z.number().nullable(),
            waterStressMax: z.number().nullable(),
            floodRiskMax: z.number().nullable(),
            currentRiskBadges: z.array(
              z.object({
                type: z.string(),
                severity: z.enum(["low", "medium", "high", "critical"]),
                label: z.string(),
              }),
            ),
          }),
        }),
        404: errorSchemas.notFound,
      },
    },
    alerts: {
      method: "GET" as const,
      path: "/api/digital-twin/climate-smart/alerts" as const,
      input: z
        .object({
          dateRange: dateRangeSchema.default("30d"),
          threshold: z.coerce.number().min(0).max(100).default(60),
          regionId: z.string().optional(),
        })
        .optional(),
      responses: {
        200: z.object({
          items: z.array(
            z.object({
              id: z.string(),
              fieldId: z.string().nullable().optional(),
              regionId: z.string().nullable().optional(),
              type: z.string(),
              severity: z.enum(["low", "medium", "high", "critical"]),
              message: z.string(),
              occurredAt: z.string(),
              payload: z.record(z.unknown()),
            }),
          ),
        }),
      },
    },
    tiles: {
      method: "GET" as const,
      path: "/api/digital-twin/climate-smart/tiles/:layer/:z/:x/:y.png" as const,
      input: z
        .object({
          date: z.string().optional(),
        })
        .optional(),
      responses: {
        200: z.any(),
        204: z.void(),
      },
    },
  },

  // Schemas exported for completeness (not directly used by generator)
  _schemas: {
    insertDtRegionSchema,
    insertDtFieldSchema,
    insertDtFieldMetricSchema,
    insertDtAlertSchema,
  },
};

export function buildUrl(
  path: string,
  params?: Record<string, string | number>,
): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export const ws = {
  channels: {
    dtAlerts: z.literal("dt-alerts"),
  },
  receive: {
    hello: z.object({ type: z.literal("hello"), channel: z.literal("dt-alerts") }),
    alert: z.object({
      type: z.literal("alert"),
      channel: z.literal("dt-alerts"),
      payload: z.object({
        id: z.string(),
        fieldId: z.string().nullable().optional(),
        regionId: z.string().nullable().optional(),
        type: z.string(),
        severity: z.enum(["low", "medium", "high", "critical"]),
        message: z.string(),
        occurredAt: z.string(),
        payload: z.record(z.unknown()),
      }),
    }),
    alerts: z.object({
      type: z.literal("alerts"),
      channel: z.literal("dt-alerts"),
      payload: z.object({
        items: z.array(
          z.object({
            id: z.string(),
            fieldId: z.string().nullable().optional(),
            regionId: z.string().nullable().optional(),
            type: z.string(),
            severity: z.enum(["low", "medium", "high", "critical"]),
            message: z.string(),
            occurredAt: z.string(),
            payload: z.record(z.unknown()),
          }),
        ),
      }),
    }),
  },
};

export type DigitalTwinSummaryInput = z.infer<
  NonNullable<(typeof api.digitalTwinClimateSmart.summary)["input"]>
>;
export type DigitalTwinSummaryResponse = z.infer<
  (typeof api.digitalTwinClimateSmart.summary.responses)[200]
>;
