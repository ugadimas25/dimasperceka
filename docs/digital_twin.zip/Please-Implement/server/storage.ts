import { db } from "./db";
import {
  users,
  type User,
  type InsertUser,
  dtRegions,
  dtFields,
  dtFieldMetrics,
  dtAlerts,
  type InsertDtRegion,
  type InsertDtField,
  type InsertDtFieldMetric,
  type InsertDtAlert,
  type DtRegion,
  type DtField,
  type DtFieldMetric,
  type DtAlert,
} from "@shared/schema";
import { eq, inArray } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Digital Twin: Climate-Smart
  listDtRegions(): Promise<DtRegion[]>;
  listDtFields(filter?: { regionId?: string; commodity?: string }): Promise<DtField[]>;
  getDtField(id: string): Promise<DtField | undefined>;
  listDtFieldMetrics(fieldId: string, opts?: { fromDate?: string }): Promise<DtFieldMetric[]>;
  listDtAlerts(opts?: {
    regionId?: string;
    fromIso?: string;
    limit?: number;
  }): Promise<DtAlert[]>;
  insertDtAlert(alert: InsertDtAlert): Promise<DtAlert>;

  // Seed
  hasDtSeed(): Promise<boolean>;
  seedDt(
    regions: InsertDtRegion[],
    fields: InsertDtField[],
    metrics: InsertDtFieldMetric[],
    alerts: InsertDtAlert[],
  ): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async listDtRegions(): Promise<DtRegion[]> {
    return await db.select().from(dtRegions);
  }

  async listDtFields(filter?: { regionId?: string; commodity?: string }): Promise<DtField[]> {
    // Simple filtering done in routes for now; keep storage minimal
    const rows = await db.select().from(dtFields);
    return rows.filter((r) => {
      if (filter?.regionId && r.regionId !== filter.regionId) return false;
      if (filter?.commodity && r.commodity !== filter.commodity) return false;
      return true;
    });
  }

  async getDtField(id: string): Promise<DtField | undefined> {
    const [row] = await db.select().from(dtFields).where(eq(dtFields.id, id));
    return row || undefined;
  }

  async listDtFieldMetrics(fieldId: string, _opts?: { fromDate?: string }): Promise<DtFieldMetric[]> {
    return await db.select().from(dtFieldMetrics).where(eq(dtFieldMetrics.fieldId, fieldId));
  }

  async listDtAlerts(opts?: {
    regionId?: string;
    fromIso?: string;
    limit?: number;
  }): Promise<DtAlert[]> {
    const rows = await db.select().from(dtAlerts);
    const filtered = rows.filter((a) => {
      if (opts?.regionId && a.regionId !== opts.regionId) return false;
      if (opts?.fromIso) {
        const from = new Date(opts.fromIso);
        if (a.occurredAt instanceof Date && a.occurredAt < from) return false;
      }
      return true;
    });
    filtered.sort((a, b) => (a.occurredAt < b.occurredAt ? 1 : -1));
    return filtered.slice(0, opts?.limit ?? 100);
  }

  async insertDtAlert(alert: InsertDtAlert): Promise<DtAlert> {
    const [row] = await db.insert(dtAlerts).values(alert).returning();
    return row;
  }

  async hasDtSeed(): Promise<boolean> {
    const regions = await db.select().from(dtRegions).limit(1);
    const fields = await db.select().from(dtFields).limit(1);
    return regions.length > 0 && fields.length > 0;
  }

  async seedDt(
    regions: InsertDtRegion[],
    fields: InsertDtField[],
    metrics: InsertDtFieldMetric[],
    alerts: InsertDtAlert[],
  ): Promise<void> {
    // idempotency: caller checks hasDtSeed before calling
    const insertedRegions = await db.insert(dtRegions).values(regions).returning();

    // Map placeholder region ids if fields include known placeholders
    const regionMap = new Map<string, string>();
    // allow referencing by index order
    insertedRegions.forEach((r, idx) => {
      regionMap.set(`region-${idx + 1}`, r.id);
    });

    const fieldsToInsert = fields.map((f) => {
      const mapped = regionMap.get(f.regionId as any);
      return {
        ...f,
        regionId: mapped ?? f.regionId,
      };
    });

    const insertedFields = await db.insert(dtFields).values(fieldsToInsert).returning();

    const fieldMap = new Map<string, string>();
    insertedFields.forEach((f, idx) => {
      fieldMap.set(`field-${idx + 1}`, f.id);
    });

    const metricsToInsert = metrics.map((m) => {
      const mappedFieldId = fieldMap.get(m.fieldId as any);
      return { ...m, fieldId: mappedFieldId ?? m.fieldId };
    });

    // Insert in chunks
    const chunkSize = 1000;
    for (let i = 0; i < metricsToInsert.length; i += chunkSize) {
      await db.insert(dtFieldMetrics).values(metricsToInsert.slice(i, i + chunkSize));
    }

    const alertsToInsert = alerts.map((a) => {
      const mappedFieldId = a.fieldId ? fieldMap.get(a.fieldId as any) : undefined;
      const mappedRegionId = a.regionId ? regionMap.get(a.regionId as any) : undefined;
      return {
        ...a,
        fieldId: mappedFieldId ?? a.fieldId,
        regionId: mappedRegionId ?? a.regionId,
      };
    });

    if (alertsToInsert.length) {
      await db.insert(dtAlerts).values(alertsToInsert);
    }
  }
}

export const storage = new DatabaseStorage();
