import type { Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { WS_CHANNELS, type DtAlertsWsMessage, type DtAlertItem } from "@shared/schema";

type ClientState = {
  ws: WebSocket;
  subscribed: boolean;
};

function safeJsonParse(data: unknown): any {
  if (typeof data !== "string") return null;
  try {
    return JSON.parse(data);
  } catch {
    return null;
  }
}

export function setupDtAlertsWs(httpServer: Server) {
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });
  const clients = new Set<ClientState>();

  function broadcast(msg: DtAlertsWsMessage) {
    const payload = JSON.stringify(msg);
    for (const c of clients) {
      if (!c.subscribed) continue;
      if (c.ws.readyState !== WebSocket.OPEN) continue;
      c.ws.send(payload);
    }
  }

  wss.on("connection", (ws) => {
    const state: ClientState = { ws, subscribed: false };
    clients.add(state);

    ws.on("message", (data) => {
      const parsed = safeJsonParse(data.toString());
      if (!parsed) return;
      if (parsed?.type === "hello" && parsed?.channel === WS_CHANNELS.dtAlerts) {
        state.subscribed = true;
        const hello: DtAlertsWsMessage = { type: "hello", channel: WS_CHANNELS.dtAlerts };
        ws.send(JSON.stringify(hello));
      }
    });

    ws.on("close", () => {
      clients.delete(state);
    });
  });

  return {
    broadcastAlert(alert: DtAlertItem) {
      broadcast({ type: "alert", channel: WS_CHANNELS.dtAlerts, payload: alert });
    },
    broadcastAlerts(items: DtAlertItem[]) {
      broadcast({ type: "alerts", channel: WS_CHANNELS.dtAlerts, payload: { items } });
    },
    getClientCount() {
      return clients.size;
    },
  };
}
