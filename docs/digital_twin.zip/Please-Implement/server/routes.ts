import type { Express } from "express";
import type { Server } from "http";
import { registerDigitalTwinClimateSmartRoutes } from "./routes/digitalTwinClimateSmart";
import { setupDtAlertsWs } from "./ws/dtAlertsChannel";
import { storage } from "./storage";
import { randomUUID } from "crypto";

import type {
  InsertDtAlert,
  InsertDtField,
  InsertDtFieldMetric,
  InsertDtRegion,
} from "@shared/schema";

function isoDay(d: Date) {
  return d.toISOString().slice(0, 10);
}

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function seeded(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

async function seedDigitalTwinClimateSmart() {
  const already = await storage.hasDtSeed();
  if (already) return;

  const regions: InsertDtRegion[] = [
    { name: "Bandung Barat" },
    { name: "Bogor Selatan" },
  ];

  const commodities = ["rice", "maize", "coffee", "cocoa", "soy"];

  const rnd = seeded(123456);

  const baseLng = 106.8;
  const baseLat = -6.2;

  const fields: InsertDtField[] = [];

  for (let i = 0; i < 20; i++) {
    const placeholderRegionId = i < 10 ? "region-1" : "region-2";

    const dx = (rnd() - 0.5) * 0.25;
    const dy = (rnd() - 0.5) * 0.25;

    const cx = baseLng + dx + (i < 10 ? 0 : 0.4);
    const cy = baseLat + dy + (i < 10 ? 0 : -0.2);

    const w = 0.01 + rnd() * 0.01;
    const h = 0.008 + rnd() * 0.008;

    const geom = {
      type: "Polygon",
      coordinates: [
        [
          [cx - w, cy - h],
          [cx + w, cy - h],
          [cx + w, cy + h],
          [cx - w, cy + h],
          [cx - w, cy - h],
        ],
      ],
    };

    const centroid = { type: "Point", coordinates: [cx, cy] };

    fields.push({
      regionId: placeholderRegionId,
      name: `Plot ${i + 1}`,
      commodity: commodities[i % commodities.length],
      geom,
      centroid,
    });
  }

  const metrics: InsertDtFieldMetric[] = [];
  const now = new Date();
  now.setUTCHours(0, 0, 0, 0);

  for (let fi = 0; fi < 20; fi++) {
    const fieldId = `field-${fi + 1}`;

    const ndviBase = 0.4 + rnd() * 0.3;
    const tempBase = 26 + rnd() * 3;

    for (let day = 89; day >= 0; day--) {
      const d = new Date(now);
      d.setUTCDate(d.getUTCDate() - day);

      const seasonal = Math.sin((day / 90) * Math.PI * 2) * 0.05;
      const noise = (rnd() - 0.5) * 0.06;

      const ndvi = clamp(ndviBase + seasonal + noise, 0, 1);
      const rainfallMm = clamp(2 + rnd() * 18 + (rnd() > 0.85 ? 25 : 0), 0, 60);
      const tempC = tempBase + (rnd() - 0.5) * 3;

      const waterStressIdx = clamp(1 - rainfallMm / 50 + (rnd() - 0.5) * 0.2, 0, 1);
      const floodRiskIdx = clamp(rainfallMm / 60 + (rnd() - 0.5) * 0.2, 0, 1);

      metrics.push({
        fieldId,
        date: isoDay(d) as any,
        ndvi,
        rainfallMm,
        tempC,
        waterStressIdx,
        floodRiskIdx,
      });
    }
  }

  const alerts: InsertDtAlert[] = [];
  for (let i = 0; i < 12; i++) {
    const fieldNum = 1 + Math.floor(rnd() * 20);
    const score = Math.round(40 + rnd() * 60);
    const occurredAt = new Date();
    occurredAt.setUTCMinutes(occurredAt.getUTCMinutes() - Math.floor(rnd() * 60 * 24 * 4));

    const severity = score >= 85 ? "critical" : score >= 70 ? "high" : score >= 55 ? "medium" : "low";

    const kind = rnd() < 0.25 ? "flood_risk" : rnd() < 0.5 ? "water_stress" : rnd() < 0.75 ? "temp_anom" : "ndvi";

    alerts.push({
      fieldId: `field-${fieldNum}`,
      regionId: fieldNum <= 10 ? "region-1" : "region-2",
      type: kind,
      severity,
      message: `${kind.replaceAll("_", " ")} detected (score ${score}) on field-${fieldNum}`,
      occurredAt,
      payload: { score, fieldId: `field-${fieldNum}`, kind },
    });
  }

  await storage.seedDt(regions, fields, metrics, alerts);
}

export async function registerRoutes(
  httpServer: Server,
  app: Express,
): Promise<Server> {
  // Feature routes
  registerDigitalTwinClimateSmartRoutes(app);

  // WebSocket
  const dtWs = setupDtAlertsWs(httpServer);

  // Seed DB once
  await seedDigitalTwinClimateSmart();

  // In mock mode (no external token) broadcast a new alert periodically
  if (!process.env.API_V2_TOKEN) {
    setInterval(async () => {
      try {
        const occurredAt = new Date();
        const fieldNum = 1 + Math.floor(Math.random() * 20);
        const score = Math.round(50 + Math.random() * 45);
        const severity = score >= 85 ? "critical" : score >= 70 ? "high" : score >= 55 ? "medium" : "low";
        const kinds = ["water_stress", "flood_risk", "temp_anom", "ndvi"];
        const kind = kinds[Math.floor(Math.random() * kinds.length)];

        const alert: InsertDtAlert = {
          fieldId: `field-${fieldNum}`,
          regionId: fieldNum <= 10 ? "region-1" : "region-2",
          type: kind,
          severity,
          message: `${kind.replaceAll("_", " ")} update (score ${score}) on field-${fieldNum}`,
          occurredAt,
          payload: { id: randomUUID(), score, fieldId: `field-${fieldNum}`, kind },
        };

        const inserted = await storage.insertDtAlert(alert);

        dtWs.broadcastAlert({
          id: inserted.id,
          fieldId: inserted.fieldId ?? null,
          regionId: inserted.regionId ?? null,
          type: inserted.type,
          severity: inserted.severity as any,
          message: inserted.message,
          occurredAt: inserted.occurredAt.toISOString(),
          payload: (inserted.payload as any) ?? {},
        });
      } catch {
        // ignore
      }
    }, 15000);
  }

  return httpServer;
}
