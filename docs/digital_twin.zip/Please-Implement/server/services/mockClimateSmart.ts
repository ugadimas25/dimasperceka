import { randomUUID } from "crypto";
import type {
  AlertSeverity,
  DateRange,
  DtAlertItem,
  DtAlertsResponse,
  DtFieldMetricsResponse,
  DtFieldsGeoJson,
  DtLayer,
  DtSummaryResponse,
} from "@shared/schema";

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function seeded(seed: number) {
  // Mulberry32
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hashStringToInt(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function daysFromRange(range: DateRange): number {
  if (range === "7d") return 7;
  if (range === "90d") return 90;
  return 30;
}

function isoDay(d: Date) {
  return d.toISOString().slice(0, 10);
}

export function mockSummary(input: {
  dateRange: DateRange;
  regionId?: string;
  commodity?: string;
}): DtSummaryResponse {
  const seedBase = hashStringToInt(
    `${input.dateRange}|${input.regionId ?? ""}|${input.commodity ?? ""}`,
  );
  const rnd = seeded(seedBase);

  const cropHealthScore = Math.round(60 + rnd() * 30);
  const climateRiskIndex = Math.round(35 + rnd() * 45);
  const waterStressPct = Math.round(10 + rnd() * 45);
  const floodWatchCount = Math.round(rnd() * 6);

  const trend = () => Math.round((rnd() * 10 - 5) * 10) / 10;

  return {
    kpis: {
      cropHealthScore,
      climateRiskIndex,
      waterStressPct,
      floodWatchCount,
      yieldForecast: null,
    },
    trends: {
      cropHealthDeltaPct: trend(),
      climateRiskDeltaPct: trend(),
      waterStressDeltaPct: trend(),
      floodWatchDeltaPct: trend(),
      yieldForecastDeltaPct: null,
    },
    stats: {
      fieldsCount: 20,
      regionsCount: 2,
      stressedFieldsCount: Math.round((waterStressPct / 100) * 20),
      highRiskFieldsCount: Math.round((climateRiskIndex / 100) * 20),
    },
  };
}

export function mockFields(input: {
  regionId?: string;
  commodity?: string;
}): DtFieldsGeoJson {
  const commodities = ["rice", "maize", "coffee", "cocoa", "soy"]; // deterministic set
  const seedBase = hashStringToInt(`${input.regionId ?? ""}|${input.commodity ?? ""}`);
  const rnd = seeded(seedBase);

  const baseLng = 106.8;
  const baseLat = -6.2;

  const features: DtFieldsGeoJson["features"] = [];

  for (let i = 0; i < 20; i++) {
    const id = `field-${i + 1}`;
    const regionId = input.regionId ?? (i < 10 ? "region-1" : "region-2");
    const commodity = input.commodity ?? commodities[i % commodities.length];

    const dx = (rnd() - 0.5) * 0.25;
    const dy = (rnd() - 0.5) * 0.25;

    const cx = baseLng + dx + (regionId === "region-2" ? 0.4 : 0);
    const cy = baseLat + dy + (regionId === "region-2" ? -0.2 : 0);

    const w = 0.01 + rnd() * 0.01;
    const h = 0.008 + rnd() * 0.008;

    const polygon = {
      type: "Polygon",
      coordinates: [
        [
          [cx - w, cy - h],
          [cx + w, cy - h],
          [cx + w, cy + h],
          [cx - w, cy + h],
          [cx - w, cy - h],
        ],
      ],
    };

    const latestNdvi = clamp(0.35 + rnd() * 0.55, 0, 1);
    const waterStressIdx = clamp(rnd(), 0, 1);
    const floodRiskIdx = clamp(rnd(), 0, 1);

    if (input.commodity && commodity !== input.commodity) continue;

    features.push({
      type: "Feature",
      id,
      geometry: polygon,
      properties: {
        id,
        name: `Plot ${i + 1}`,
        regionId,
        commodity,
        latestNdvi: Math.round(latestNdvi * 1000) / 1000,
        waterStressIdx: Math.round(waterStressIdx * 1000) / 1000,
        floodRiskIdx: Math.round(floodRiskIdx * 1000) / 1000,
      },
    });
  }

  return {
    type: "FeatureCollection",
    features,
  };
}

export function mockFieldMetrics(input: {
  fieldId: string;
  dateRange: DateRange;
}): DtFieldMetricsResponse {
  const days = daysFromRange(input.dateRange);
  const seedBase = hashStringToInt(`${input.fieldId}|${input.dateRange}`);
  const rnd = seeded(seedBase);

  const series: DtFieldMetricsResponse["series"] = [];

  const ndviBase = 0.4 + rnd() * 0.3;
  const tempBase = 26 + rnd() * 3;

  for (let i = days - 1; i >= 0; i--) {
    const d = new Date();
    d.setUTCDate(d.getUTCDate() - i);

    const seasonal = Math.sin((i / days) * Math.PI * 2) * 0.05;
    const noise = (rnd() - 0.5) * 0.06;

    const ndvi = clamp(ndviBase + seasonal + noise, 0, 1);
    const rainfallMm = clamp(2 + rnd() * 18 + (rnd() > 0.8 ? 25 : 0), 0, 60);
    const tempC = tempBase + (rnd() - 0.5) * 3;

    const waterStressIdx = clamp(1 - rainfallMm / 50 + (rnd() - 0.5) * 0.2, 0, 1);
    const floodRiskIdx = clamp(rainfallMm / 60 + (rnd() - 0.5) * 0.2, 0, 1);

    const rainfallAnom = clamp((rainfallMm - 12) / 20, -2, 2);
    const tempAnom = clamp((tempC - 27) / 3, -2, 2);

    const riskScore = clamp(
      Math.round((waterStressIdx * 40 + floodRiskIdx * 35 + tempAnom * 10 + (1 - ndvi) * 30) * 10) /
        10,
      0,
      100,
    );

    series.push({
      date: isoDay(d),
      ndvi: Math.round(ndvi * 1000) / 1000,
      rainfallMm: Math.round(rainfallMm * 10) / 10,
      tempC: Math.round(tempC * 10) / 10,
      waterStressIdx: Math.round(waterStressIdx * 1000) / 1000,
      floodRiskIdx: Math.round(floodRiskIdx * 1000) / 1000,
      rainfallAnom: Math.round(rainfallAnom * 100) / 100,
      tempAnom: Math.round(tempAnom * 100) / 100,
      riskScore,
    });
  }

  const ndviAvg = series.reduce((acc, s) => acc + (s.ndvi ?? 0), 0) / series.length;
  const rainfallTotalMm = series.reduce((acc, s) => acc + (s.rainfallMm ?? 0), 0);
  const tempAvgC = series.reduce((acc, s) => acc + (s.tempC ?? 0), 0) / series.length;
  const waterStressMax = Math.max(...series.map((s) => s.waterStressIdx ?? 0));
  const floodRiskMax = Math.max(...series.map((s) => s.floodRiskIdx ?? 0));

  const badges: DtFieldMetricsResponse["summary"]["currentRiskBadges"] = [];
  const last = series[series.length - 1];
  if ((last.waterStressIdx ?? 0) > 0.7) {
    badges.push({ type: "water_stress", severity: "high", label: "High water stress" });
  }
  if ((last.floodRiskIdx ?? 0) > 0.7) {
    badges.push({ type: "flood_risk", severity: "high", label: "Flood risk" });
  }
  if ((last.tempAnom ?? 0) > 1.0) {
    badges.push({ type: "heat", severity: "medium", label: "Heat anomaly" });
  }
  if ((last.ndvi ?? 1) < 0.45) {
    badges.push({ type: "ndvi", severity: "medium", label: "Low NDVI" });
  }

  return {
    field: {
      id: input.fieldId,
      name: input.fieldId.startsWith("field-")
        ? `Plot ${Number(input.fieldId.replace("field-", ""))}`
        : input.fieldId,
      regionId: input.fieldId.endsWith("1") ? "region-1" : "region-2",
      commodity: "rice",
    },
    series,
    summary: {
      ndviAvg: Math.round(ndviAvg * 1000) / 1000,
      rainfallTotalMm: Math.round(rainfallTotalMm * 10) / 10,
      tempAvgC: Math.round(tempAvgC * 10) / 10,
      waterStressMax: Math.round(waterStressMax * 1000) / 1000,
      floodRiskMax: Math.round(floodRiskMax * 1000) / 1000,
      currentRiskBadges: badges,
    },
  };
}

function severityFromScore(score: number): AlertSeverity {
  if (score >= 85) return "critical";
  if (score >= 70) return "high";
  if (score >= 55) return "medium";
  return "low";
}

export function mockAlerts(input: {
  dateRange: DateRange;
  threshold: number;
  regionId?: string;
}): DtAlertsResponse {
  const seedBase = hashStringToInt(`${input.dateRange}|${input.threshold}|${input.regionId ?? ""}`);
  const rnd = seeded(seedBase);

  const types = ["High water stress", "Flood risk", "Heat anomaly", "Low NDVI"];

  const count = clamp(Math.round(5 + rnd() * 8), 3, 12);
  const items: DtAlertItem[] = [];

  for (let i = 0; i < count; i++) {
    const fieldNum = 1 + Math.floor(rnd() * 20);
    const fieldId = `field-${fieldNum}`;
    const score = Math.round(40 + rnd() * 60);
    if (score < input.threshold) continue;

    const type = types[Math.floor(rnd() * types.length)];
    const severity = severityFromScore(score);

    const occurredAt = new Date();
    occurredAt.setUTCMinutes(occurredAt.getUTCMinutes() - Math.floor(rnd() * 60 * 24 * 3));

    items.push({
      id: randomUUID(),
      fieldId,
      regionId: input.regionId ?? null,
      type: type.toLowerCase().replaceAll(" ", "_"),
      severity,
      message: `${type} detected (score ${score}) on ${fieldId}`,
      occurredAt: occurredAt.toISOString(),
      payload: {
        score,
        fieldId,
        kind: type,
      },
    });
  }

  items.sort((a, b) => (a.occurredAt < b.occurredAt ? 1 : -1));

  return { items };
}

export function mockTileBehavior(_layer: DtLayer) {
  // In mock mode we return 204 (no content). Frontend should still work.
  return { status: 204 as const };
}
