import { URL } from "url";

const API_BASE = "https://api-v2.sustainit.id";

export type GeeLayer =
  | "ndvi"
  | "rainfall_anom"
  | "temp_anom"
  | "flood_risk"
  | "water_stress";

export function hasApiToken() {
  return Boolean(process.env.API_V2_TOKEN);
}

export function buildTileUrl(params: {
  layer: GeeLayer;
  z: string;
  x: string;
  y: string;
  date?: string;
}) {
  // Assumption: upstream endpoint path mirrors ours under /digital-twin/climate-smart
  // If upstream differs, adjust in one place here.
  const url = new URL(
    `${API_BASE}/digital-twin/climate-smart/tiles/${params.layer}/${params.z}/${params.x}/${params.y}.png`,
  );
  if (params.date) url.searchParams.set("date", params.date);
  return url;
}

export async function fetchTilePng(params: {
  layer: GeeLayer;
  z: string;
  x: string;
  y: string;
  date?: string;
}) {
  const url = buildTileUrl(params);

  const res = await fetch(url.toString(), {
    headers: {
      Authorization: `Bearer ${process.env.API_V2_TOKEN}`,
      Accept: "image/png",
    },
  });

  return res;
}
