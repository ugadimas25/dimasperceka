import type { Express } from "express";
import { and, desc, eq, gte, inArray, lte, sql } from "drizzle-orm";
import { z } from "zod";
import { api, buildUrl, errorSchemas } from "@shared/routes";
import {
  dtAlerts,
  dtFieldMetrics,
  dtFields,
  dtRegions,
  type DateRange,
  type DtAlertItem,
  type DtFieldsGeoJson,
  type DtSummaryResponse,
} from "@shared/schema";
import { db } from "../db";
import { hasApiToken, fetchTilePng, type GeeLayer } from "../services/geeProxy";
import {
  mockAlerts,
  mockFieldMetrics,
  mockFields,
  mockSummary,
  mockTileBehavior,
} from "../services/mockClimateSmart";

function daysFromRange(r: DateRange) {
  if (r === "7d") return 7;
  if (r === "90d") return 90;
  return 30;
}

function dateFloorFromRange(r: DateRange) {
  const d = new Date();
  d.setUTCHours(0, 0, 0, 0);
  d.setUTCDate(d.getUTCDate() - (daysFromRange(r) - 1));
  return d;
}

function toAlertItem(row: any): DtAlertItem {
  return {
    id: row.id,
    fieldId: row.fieldId ?? null,
    regionId: row.regionId ?? null,
    type: row.type,
    severity: row.severity,
    message: row.message,
    occurredAt: row.occurredAt instanceof Date ? row.occurredAt.toISOString() : String(row.occurredAt),
    payload: row.payload ?? {},
  };
}

export function registerDigitalTwinClimateSmartRoutes(app: Express) {
  // Summary
  app.get(api.digitalTwinClimateSmart.summary.path, async (req, res) => {
    const input = api.digitalTwinClimateSmart.summary.input?.parse(req.query);
    const dateRange = (input?.dateRange ?? "30d") as DateRange;

    try {
      const hasData = await db.select({ count: sql<number>`count(*)` }).from(dtFields);
      if (!hasData?.[0] || Number(hasData[0].count) === 0) {
        const mock = mockSummary({
          dateRange,
          regionId: input?.regionId,
          commodity: input?.commodity,
        });
        return res.json(mock);
      }

      // Compute KPIs from latest metrics per field within range
      const from = dateFloorFromRange(dateRange);

      const fieldsWhere = and(
        input?.regionId ? eq(dtFields.regionId, input.regionId) : undefined,
        input?.commodity ? eq(dtFields.commodity, input.commodity) : undefined,
      );

      const fields = await db
        .select({ id: dtFields.id })
        .from(dtFields)
        .where(fieldsWhere);

      const fieldIds = fields.map((f) => f.id);
      if (fieldIds.length === 0) {
        const empty: DtSummaryResponse = mockSummary({
          dateRange,
          regionId: input?.regionId,
          commodity: input?.commodity,
        });
        empty.stats.fieldsCount = 0;
        return res.json(empty);
      }

      // Latest metric per field
      const metrics = await db
        .select({
          fieldId: dtFieldMetrics.fieldId,
          date: dtFieldMetrics.date,
          ndvi: dtFieldMetrics.ndvi,
          waterStressIdx: dtFieldMetrics.waterStressIdx,
          floodRiskIdx: dtFieldMetrics.floodRiskIdx,
          tempC: dtFieldMetrics.tempC,
          rainfallMm: dtFieldMetrics.rainfallMm,
        })
        .from(dtFieldMetrics)
        .where(and(inArray(dtFieldMetrics.fieldId, fieldIds), gte(dtFieldMetrics.createdAt, from)))
        .orderBy(desc(dtFieldMetrics.date));

      const latestByField = new Map<string, typeof metrics[number]>();
      for (const m of metrics) {
        if (!latestByField.has(m.fieldId)) latestByField.set(m.fieldId, m);
      }

      const latest = Array.from(latestByField.values());

      const avg = (arr: Array<number | null | undefined>) => {
        const vals = arr.filter((v): v is number => typeof v === "number" && Number.isFinite(v));
        if (vals.length === 0) return null;
        return vals.reduce((a, b) => a + b, 0) / vals.length;
      };

      const ndviAvg = avg(latest.map((m) => m.ndvi));
      const waterStressAvg = avg(latest.map((m) => m.waterStressIdx));
      const floodRiskAvg = avg(latest.map((m) => m.floodRiskIdx));

      const cropHealthScore = ndviAvg == null ? 0 : Math.round(ndviAvg * 100);
      const climateRiskIndex =
        waterStressAvg == null || floodRiskAvg == null
          ? 0
          : Math.round((waterStressAvg * 55 + floodRiskAvg * 45) * 100) / 1;

      const stressedFieldsCount = latest.filter((m) => (m.waterStressIdx ?? 0) > 0.7).length;
      const floodWatchCount = latest.filter((m) => (m.floodRiskIdx ?? 0) > 0.7).length;

      const response: DtSummaryResponse = {
        kpis: {
          cropHealthScore: Math.round(cropHealthScore),
          climateRiskIndex: Math.round(climateRiskIndex),
          waterStressPct: fieldIds.length ? Math.round((stressedFieldsCount / fieldIds.length) * 100) : 0,
          floodWatchCount,
          yieldForecast: null,
        },
        trends: {
          cropHealthDeltaPct: 0,
          climateRiskDeltaPct: 0,
          waterStressDeltaPct: 0,
          floodWatchDeltaPct: 0,
          yieldForecastDeltaPct: null,
        },
        stats: {
          fieldsCount: fieldIds.length,
          regionsCount: (await db.select({ count: sql<number>`count(*)` }).from(dtRegions))[0]
            ? Number((await db.select({ count: sql<number>`count(*)` }).from(dtRegions))[0].count)
            : 0,
          stressedFieldsCount,
          highRiskFieldsCount: latest.filter((m) => ((m.waterStressIdx ?? 0) + (m.floodRiskIdx ?? 0)) / 2 > 0.7).length,
        },
      };

      return res.json(response);
    } catch {
      const mock = mockSummary({
        dateRange,
        regionId: input?.regionId,
        commodity: input?.commodity,
      });
      return res.json(mock);
    }
  });

  // Fields GeoJSON
  app.get(api.digitalTwinClimateSmart.fields.path, async (req, res) => {
    const input = api.digitalTwinClimateSmart.fields.input?.parse(req.query);

    try {
      const hasData = await db.select({ count: sql<number>`count(*)` }).from(dtFields);
      if (!hasData?.[0] || Number(hasData[0].count) === 0) {
        return res.json(mockFields({ regionId: input?.regionId, commodity: input?.commodity }));
      }

      const where = and(
        input?.regionId ? eq(dtFields.regionId, input.regionId) : undefined,
        input?.commodity ? eq(dtFields.commodity, input.commodity) : undefined,
      );

      const rows = await db
        .select({
          id: dtFields.id,
          name: dtFields.name,
          regionId: dtFields.regionId,
          commodity: dtFields.commodity,
          geom: dtFields.geom,
        })
        .from(dtFields)
        .where(where);

      // Latest metrics for minimal properties
      const ids = rows.map((r) => r.id);
      const metrics = ids.length
        ? await db
            .select({
              fieldId: dtFieldMetrics.fieldId,
              date: dtFieldMetrics.date,
              ndvi: dtFieldMetrics.ndvi,
              waterStressIdx: dtFieldMetrics.waterStressIdx,
              floodRiskIdx: dtFieldMetrics.floodRiskIdx,
            })
            .from(dtFieldMetrics)
            .where(inArray(dtFieldMetrics.fieldId, ids))
            .orderBy(desc(dtFieldMetrics.date))
        : [];

      const latestByField = new Map<string, typeof metrics[number]>();
      for (const m of metrics) {
        if (!latestByField.has(m.fieldId)) latestByField.set(m.fieldId, m);
      }

      const fc: DtFieldsGeoJson = {
        type: "FeatureCollection",
        features: rows.map((r) => {
          const latest = latestByField.get(r.id);
          return {
            type: "Feature",
            id: r.id,
            geometry: r.geom as any,
            properties: {
              id: r.id,
              name: r.name,
              regionId: r.regionId,
              commodity: r.commodity,
              latestNdvi: latest?.ndvi ?? null,
              waterStressIdx: latest?.waterStressIdx ?? null,
              floodRiskIdx: latest?.floodRiskIdx ?? null,
            },
          };
        }),
      };

      return res.json(fc);
    } catch {
      return res.json(mockFields({ regionId: input?.regionId, commodity: input?.commodity }));
    }
  });

  // Field metrics
  app.get(api.digitalTwinClimateSmart.fieldMetrics.path, async (req, res) => {
    const id = String(req.params.id);
    const input = api.digitalTwinClimateSmart.fieldMetrics.input?.parse(req.query);
    const dateRange = (input?.dateRange ?? "30d") as DateRange;

    try {
      const [field] = await db
        .select({
          id: dtFields.id,
          name: dtFields.name,
          regionId: dtFields.regionId,
          commodity: dtFields.commodity,
        })
        .from(dtFields)
        .where(eq(dtFields.id, id));

      if (!field) {
        // mock fallback for unknown id
        return res.json(mockFieldMetrics({ fieldId: id, dateRange }));
      }

      const from = dateFloorFromRange(dateRange);
      const rows = await db
        .select({
          date: dtFieldMetrics.date,
          ndvi: dtFieldMetrics.ndvi,
          rainfallMm: dtFieldMetrics.rainfallMm,
          tempC: dtFieldMetrics.tempC,
          waterStressIdx: dtFieldMetrics.waterStressIdx,
          floodRiskIdx: dtFieldMetrics.floodRiskIdx,
        })
        .from(dtFieldMetrics)
        .where(and(eq(dtFieldMetrics.fieldId, id), gte(dtFieldMetrics.createdAt, from)))
        .orderBy(dtFieldMetrics.date);

      const series = rows.map((r) => {
        const date = typeof r.date === "string" ? r.date : String(r.date);
        const ndvi = r.ndvi ?? null;
        const rainfallMm = r.rainfallMm ?? null;
        const tempC = r.tempC ?? null;
        const waterStressIdx = r.waterStressIdx ?? null;
        const floodRiskIdx = r.floodRiskIdx ?? null;

        const rainfallAnom = rainfallMm == null ? null : (rainfallMm - 12) / 20;
        const tempAnom = tempC == null ? null : (tempC - 27) / 3;

        const riskScore = Math.max(
          0,
          Math.min(
            100,
            Math.round(
              ((waterStressIdx ?? 0) * 40 + (floodRiskIdx ?? 0) * 35 + (tempAnom ?? 0) * 10 + (1 - (ndvi ?? 1)) * 30) *
                10,
            ) / 10,
          ),
        );

        return {
          date,
          ndvi,
          rainfallMm,
          tempC,
          waterStressIdx,
          floodRiskIdx,
          rainfallAnom,
          tempAnom,
          riskScore,
        };
      });

      const avg = (arr: Array<number | null>) => {
        const vals = arr.filter((v): v is number => typeof v === "number" && Number.isFinite(v));
        if (vals.length === 0) return null;
        return vals.reduce((a, b) => a + b, 0) / vals.length;
      };

      const sum = (arr: Array<number | null>) => {
        const vals = arr.filter((v): v is number => typeof v === "number" && Number.isFinite(v));
        if (vals.length === 0) return null;
        return vals.reduce((a, b) => a + b, 0);
      };

      const waterStressMax =
        series.length === 0 ? null : Math.max(...series.map((s) => s.waterStressIdx ?? 0));
      const floodRiskMax =
        series.length === 0 ? null : Math.max(...series.map((s) => s.floodRiskIdx ?? 0));

      const last = series[series.length - 1];
      const currentRiskBadges: any[] = [];
      if ((last?.waterStressIdx ?? 0) > 0.7) {
        currentRiskBadges.push({ type: "water_stress", severity: "high", label: "High water stress" });
      }
      if ((last?.floodRiskIdx ?? 0) > 0.7) {
        currentRiskBadges.push({ type: "flood_risk", severity: "high", label: "Flood risk" });
      }
      if ((last?.tempAnom ?? 0) > 1.0) {
        currentRiskBadges.push({ type: "heat", severity: "medium", label: "Heat anomaly" });
      }
      if ((last?.ndvi ?? 1) < 0.45) {
        currentRiskBadges.push({ type: "ndvi", severity: "medium", label: "Low NDVI" });
      }

      return res.json({
        field,
        series,
        summary: {
          ndviAvg: avg(series.map((s) => s.ndvi)),
          rainfallTotalMm: sum(series.map((s) => s.rainfallMm)),
          tempAvgC: avg(series.map((s) => s.tempC)),
          waterStressMax,
          floodRiskMax,
          currentRiskBadges,
        },
      });
    } catch (err) {
      // If DB issues, still return deterministic mock data
      return res.json(mockFieldMetrics({ fieldId: id, dateRange }));
    }
  });

  // Alerts
  app.get(api.digitalTwinClimateSmart.alerts.path, async (req, res) => {
    const input = api.digitalTwinClimateSmart.alerts.input?.parse(req.query);
    const dateRange = (input?.dateRange ?? "30d") as DateRange;
    const threshold = input?.threshold ?? 60;

    try {
      const hasData = await db.select({ count: sql<number>`count(*)` }).from(dtAlerts);
      if (!hasData?.[0] || Number(hasData[0].count) === 0) {
        return res.json(mockAlerts({ dateRange, threshold, regionId: input?.regionId }));
      }

      const from = dateFloorFromRange(dateRange);
      const where = and(
        gte(dtAlerts.occurredAt, from),
        input?.regionId ? eq(dtAlerts.regionId, input.regionId) : undefined,
      );

      const rows = await db
        .select({
          id: dtAlerts.id,
          fieldId: dtAlerts.fieldId,
          regionId: dtAlerts.regionId,
          type: dtAlerts.type,
          severity: dtAlerts.severity,
          message: dtAlerts.message,
          occurredAt: dtAlerts.occurredAt,
          payload: dtAlerts.payload,
        })
        .from(dtAlerts)
        .where(where)
        .orderBy(desc(dtAlerts.occurredAt))
        .limit(100);

      // Client threshold is 0-100; payload may contain score
      const items = rows
        .map(toAlertItem)
        .filter((a) => {
          const score = typeof a.payload?.score === "number" ? (a.payload.score as number) : null;
          if (score == null) return true;
          return score >= threshold;
        });

      return res.json({ items });
    } catch {
      return res.json(mockAlerts({ dateRange, threshold, regionId: input?.regionId }));
    }
  });

  // Tiles proxy
  app.get(api.digitalTwinClimateSmart.tiles.path, async (req, res) => {
    const layer = String(req.params.layer) as GeeLayer;
    const z = String(req.params.z);
    const x = String(req.params.x);
    const y = String(req.params.y);
    const input = api.digitalTwinClimateSmart.tiles.input?.parse(req.query);

    const allowed = ["ndvi", "rainfall_anom", "temp_anom", "flood_risk", "water_stress"] as const;
    if (!allowed.includes(layer as any)) {
      return res.status(400).json({ message: "Unknown layer" });
    }

    // Mock mode: no token
    if (!hasApiToken()) {
      const mock = mockTileBehavior(layer as any);
      if (mock.status === 204) return res.status(204).end();
    }

    try {
      const upstream = await fetchTilePng({ layer, z, x, y, date: input?.date });

      if (upstream.status === 204) {
        return res.status(204).end();
      }

      if (!upstream.ok) {
        // graceful fallback
        return res.status(204).end();
      }

      const buf = Buffer.from(await upstream.arrayBuffer());
      res.setHeader("Content-Type", "image/png");
      res.setHeader("Cache-Control", "public, max-age=60");
      return res.status(200).send(buf);
    } catch {
      // mock if unreachable
      return res.status(204).end();
    }
  });
}
