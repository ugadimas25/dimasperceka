## Packages
maplibre-gl | Map rendering for the Digital Twin (MapLibre GL JS)
react-map-gl | React wrapper for MapLibre for cleaner map composition (use Map from react-map-gl/maplibre)

## Notes
MapLibre style URL: https://demotiles.maplibre.org/style.json
WebSocket: same-origin ws endpoint at /ws; send {"type":"hello","channel":"dt-alerts"} after connect
All fetch calls must include credentials: "include"
Zod parsing: use safeParse + console.error formatting for debugging API mismatches
