import AppShell from "@/components/AppShell";
import SectionHeader from "@/components/SectionHeader";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, Globe2 } from "lucide-react";
import { Card } from "@/components/ui/card";

export default function Home() {
  return (
    <AppShell>
      <div className="space-y-6">
        <SectionHeader
          title="Climate‑Smart Digital Twin"
          subtitle="A dark‑mode, analyst-grade cockpit: KPIs, live alerts, and field-level time series—paired with an interactive map."
          right={
            <Link
              href="/digital-twin/climate-smart"
              className="inline-flex"
              data-testid="home-open-module-link"
            >
              <Button
                className="rounded-xl bg-gradient-to-r from-primary to-accent text-primary-foreground shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/25"
                onClick={() => {}}
                data-testid="home-open-module"
              >
                Open the Twin <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          }
          testId="home-header"
        />

        <div className="grid gap-4 md:grid-cols-2">
          <Card className="glass-panel hover-lift rounded-3xl p-5">
            <div className="flex items-start gap-3">
              <div className="grid h-11 w-11 place-items-center rounded-2xl border border-border/70 bg-card/60">
                <Globe2 className="h-5 w-5 text-primary" />
              </div>
              <div className="min-w-0">
                <div className="text-lg font-extrabold tracking-tight">Field Intelligence</div>
                <p className="mt-1 text-sm text-muted-foreground">
                  Explore field boundaries, click into a detail panel, and inspect NDVI and risk trends across 7/30/90 days.
                </p>
              </div>
            </div>
          </Card>

          <Card className="glass-panel hover-lift rounded-3xl p-5">
            <div className="text-lg font-extrabold tracking-tight">Live Risk Signals</div>
            <p className="mt-1 text-sm text-muted-foreground">
              Alerts stream in over WebSocket. New events are highlighted immediately—so you can react before the next storm.
            </p>
            <div className="mt-4 flex flex-wrap gap-2 text-xs text-muted-foreground">
              <span className="rounded-full border border-border/70 bg-card/50 px-3 py-1">Flood risk</span>
              <span className="rounded-full border border-border/70 bg-card/50 px-3 py-1">Water stress</span>
              <span className="rounded-full border border-border/70 bg-card/50 px-3 py-1">Thermal anomaly</span>
              <span className="rounded-full border border-border/70 bg-card/50 px-3 py-1">Rainfall anomaly</span>
            </div>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}
