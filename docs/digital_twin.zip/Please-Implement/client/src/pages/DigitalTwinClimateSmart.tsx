import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import AppShell from "@/components/AppShell";
import SectionHeader from "@/components/SectionHeader";
import MetricCard from "@/components/MetricCard";
import DtMap from "@/components/DtMap";
import FieldDetailsDialog from "@/components/FieldDetailsDialog";
import SeverityBadge from "@/components/SeverityBadge";

import { api } from "@shared/routes";
import type { DateRange, DtLayer } from "@shared/schema";
import {
  useDtAlerts,
  useDtAlertsWebSocket,
  useDtFieldMetrics,
  useDtFieldsGeoJson,
  useDtSummary,
  useInvalidateDigitalTwin,
} from "@/hooks/use-dt-climate-smart";

import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

import {
  Activity,
  AlertTriangle,
  Droplets,
  Factory,
  Leaf,
  MapPinned,
  RefreshCw,
  ShieldAlert,
  ThermometerSun,
  Waves,
} from "lucide-react";

import {
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip as ReTooltip,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";

function fmtPct(v: number) {
  return `${v.toFixed(1)}%`;
}

function safeNum(v: number | null | undefined, digits = 1) {
  if (v === null || v === undefined || Number.isNaN(v)) return "—";
  return v.toFixed(digits);
}

function dateTick(v: string) {
  try {
    return new Date(v).toLocaleDateString(undefined, { month: "short", day: "numeric" });
  } catch {
    return v;
  }
}

export default function DigitalTwinClimateSmart() {
  const { toast } = useToast();

  const [dateRange, setDateRange] = useState<DateRange>("30d");
  const [regionId, setRegionId] = useState<string | undefined>(undefined);
  const [commodity, setCommodity] = useState<string | undefined>(undefined);
  const [threshold, setThreshold] = useState<number>(60);
  const [layer, setLayer] = useState<DtLayer>("ndvi");

  const [showRaster, setShowRaster] = useState(true);
  const [showFields, setShowFields] = useState(true);

  const [selectedFieldId, setSelectedFieldId] = useState<string | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);

  const summaryQ = useDtSummary({ dateRange, regionId, commodity });
  const fieldsQ = useDtFieldsGeoJson({ regionId, commodity });
  const alertsQ = useDtAlerts({ dateRange, threshold, regionId });
  const metricsQ = useDtFieldMetrics(selectedFieldId, { dateRange });

  const { connected, lastAlert } = useDtAlertsWebSocket();
  const invalidate = useInvalidateDigitalTwin();

  useEffect(() => {
    if (summaryQ.isError) {
      toast({
        title: "Summary failed to load",
        description: "Check server logs if this persists.",
        variant: "destructive",
      });
    }
  }, [summaryQ.isError, toast]);

  useEffect(() => {
    if (fieldsQ.isError) {
      toast({
        title: "Fields failed to load",
        description: "GeoJSON boundaries endpoint returned an error.",
        variant: "destructive",
      });
    }
  }, [fieldsQ.isError, toast]);

  useEffect(() => {
    if (alertsQ.isError) {
      toast({
        title: "Alerts failed to load",
        description: "Try reducing threshold or switching date range.",
        variant: "destructive",
      });
    }
  }, [alertsQ.isError, toast]);

  // When field selected, open dialog
  useEffect(() => {
    if (selectedFieldId) setDetailsOpen(true);
  }, [selectedFieldId]);

  const kpis = summaryQ.data?.kpis;
  const trends = summaryQ.data?.trends;
  const stats = summaryQ.data?.stats;

  const regionOptions = useMemo(() => {
    // No regions endpoint; infer from fields payload.
    const feats = fieldsQ.data?.features ?? [];
    const ids = new Set<string>();
    feats.forEach((f) => ids.add(f.properties.regionId));
    return Array.from(ids).sort();
  }, [fieldsQ.data]);

  const commodityOptions = useMemo(() => {
    const feats = fieldsQ.data?.features ?? [];
    const ids = new Set<string>();
    feats.forEach((f) => ids.add(f.properties.commodity));
    return Array.from(ids).sort();
  }, [fieldsQ.data]);

  const alerts = alertsQ.data?.items ?? [];

  const sparkSeries = useMemo(() => {
    const s = metricsQ.data?.series ?? [];
    return s.map((d) => ({
      date: d.date,
      ndvi: d.ndvi ?? null,
      risk: d.riskScore,
      water: d.waterStressIdx ?? null,
      flood: d.floodRiskIdx ?? null,
      temp: d.tempC ?? null,
      rain: d.rainfallMm ?? null,
    }));
  }, [metricsQ.data]);

  const analyticsSeries = useMemo(() => {
    // Small “global” chart from summary stats doesn't exist; use alerts histogram-ish (fake series)
    // We'll derive a simple risk trend from most recent alerts (by occurredAt).
    const recent = [...alerts]
      .sort((a, b) => +new Date(a.occurredAt) - +new Date(b.occurredAt))
      .slice(-30);

    return recent.map((a, idx) => ({
      i: idx + 1,
      severity:
        a.severity === "critical" ? 100 : a.severity === "high" ? 75 : a.severity === "medium" ? 45 : 20,
      t: a.occurredAt,
    }));
  }, [alerts]);

  return (
    <AppShell>
      <div className="space-y-6" data-testid="dt-climate-smart-page">
        <SectionHeader
          title="Climate‑Smart Twin"
          subtitle="Dial in a region, pick a layer, set a risk threshold, and watch your alert stream update in real time."
          right={
            <>
              <div className="hidden items-center gap-2 md:flex">
                <Badge
                  className="rounded-full border border-border/70 bg-card/50 px-3 py-1 text-xs"
                  data-testid="ws-status-badge"
                >
                  <span className={`mr-2 inline-block h-2 w-2 rounded-full ${connected ? "bg-emerald-400" : "bg-muted-foreground/50"}`} />
                  {connected ? "Live" : "Connecting"}
                </Badge>
              </div>

              <Button
                variant="secondary"
                className="rounded-xl border border-border/70 bg-card/45 hover:bg-card/70"
                onClick={() => invalidate.mutate()}
                disabled={invalidate.isPending}
                data-testid="refresh-button"
              >
                <RefreshCw className={`mr-2 h-4 w-4 ${invalidate.isPending ? "animate-spin" : ""}`} />
                Refresh
              </Button>
            </>
          }
          testId="dt-header"
        />

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* LEFT PANEL */}
          <motion.div
            className="glass-panel hover-lift lg:col-span-4"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.2, 0.9, 0.2, 1] }}
            data-testid="left-panel"
          >
            <div className="border-b border-border/70 p-5">
              <div className="flex items-center justify-between gap-4">
                <div className="min-w-0">
                  <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Filters
                  </div>
                  <div className="mt-1 text-lg font-extrabold tracking-tight">
                    Scope & thresholds
                  </div>
                </div>
                <div className="inline-flex items-center gap-2 rounded-2xl border border-border/70 bg-card/40 px-3 py-2 text-xs text-muted-foreground">
                  <Factory className="h-4 w-4 text-primary" />
                  Query keys:{" "}
                  <span className="font-semibold text-foreground">
                    {api.digitalTwinClimateSmart.summary.path}
                  </span>
                </div>
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                <div>
                  <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Date range
                  </div>
                  <Select
                    value={dateRange}
                    onValueChange={(v) => setDateRange(v as DateRange)}
                  >
                    <SelectTrigger className="focus-premium rounded-xl border-border/70 bg-background/30" data-testid="select-dateRange">
                      <SelectValue placeholder="Select range" />
                    </SelectTrigger>
                    <SelectContent className="rounded-2xl border-border/70 bg-popover/95 backdrop-blur-xl">
                      <SelectItem value="7d">Last 7 days</SelectItem>
                      <SelectItem value="30d">Last 30 days</SelectItem>
                      <SelectItem value="90d">Last 90 days</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Layer
                  </div>
                  <Select value={layer} onValueChange={(v) => setLayer(v as DtLayer)}>
                    <SelectTrigger className="focus-premium rounded-xl border-border/70 bg-background/30" data-testid="select-layer">
                      <SelectValue placeholder="Select layer" />
                    </SelectTrigger>
                    <SelectContent className="rounded-2xl border-border/70 bg-popover/95 backdrop-blur-xl">
                      <SelectItem value="ndvi">NDVI</SelectItem>
                      <SelectItem value="rainfall_anom">Rainfall anomaly</SelectItem>
                      <SelectItem value="temp_anom">Temp anomaly</SelectItem>
                      <SelectItem value="flood_risk">Flood risk</SelectItem>
                      <SelectItem value="water_stress">Water stress</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Region
                  </div>
                  <Select
                    value={regionId ?? "all"}
                    onValueChange={(v) => setRegionId(v === "all" ? undefined : v)}
                  >
                    <SelectTrigger className="focus-premium rounded-xl border-border/70 bg-background/30" data-testid="select-regionId">
                      <SelectValue placeholder="All regions" />
                    </SelectTrigger>
                    <SelectContent className="rounded-2xl border-border/70 bg-popover/95 backdrop-blur-xl">
                      <SelectItem value="all">All regions</SelectItem>
                      {regionOptions.map((r) => (
                        <SelectItem key={r} value={r}>
                          {r}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Commodity
                  </div>
                  <Select
                    value={commodity ?? "all"}
                    onValueChange={(v) => setCommodity(v === "all" ? undefined : v)}
                  >
                    <SelectTrigger className="focus-premium rounded-xl border-border/70 bg-background/30" data-testid="select-commodity">
                      <SelectValue placeholder="All commodities" />
                    </SelectTrigger>
                    <SelectContent className="rounded-2xl border-border/70 bg-popover/95 backdrop-blur-xl">
                      <SelectItem value="all">All commodities</SelectItem>
                      {commodityOptions.map((c) => (
                        <SelectItem key={c} value={c}>
                          {c}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="mt-4 rounded-2xl border border-border/70 bg-background/20 p-4">
                <div className="flex items-center justify-between gap-4">
                  <div className="min-w-0">
                    <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                      Risk threshold
                    </div>
                    <div className="mt-1 text-sm text-muted-foreground">
                      Only show alerts at or above this score.
                    </div>
                  </div>
                  <div
                    className="rounded-full border border-border/70 bg-card/50 px-3 py-1 text-sm font-extrabold"
                    data-testid="threshold-value"
                  >
                    {threshold}
                  </div>
                </div>

                <div className="mt-3">
                  <Slider
                    value={[threshold]}
                    onValueChange={(v) => setThreshold(v?.[0] ?? 60)}
                    min={0}
                    max={100}
                    step={1}
                    className="py-2"
                    data-testid="threshold-slider"
                  />
                </div>
              </div>

              <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 rounded-2xl border border-border/70 bg-card/45 px-3 py-2">
                    <Switch
                      checked={showFields}
                      onCheckedChange={setShowFields}
                      data-testid="toggle-fields"
                    />
                    <div className="text-xs font-semibold text-muted-foreground">Field polygons</div>
                  </div>

                  <div className="flex items-center gap-2 rounded-2xl border border-border/70 bg-card/45 px-3 py-2">
                    <Switch
                      checked={showRaster}
                      onCheckedChange={setShowRaster}
                      data-testid="toggle-raster"
                    />
                    <div className="text-xs font-semibold text-muted-foreground">Raster tiles</div>
                  </div>
                </div>

                <Button
                  className="rounded-xl bg-gradient-to-r from-primary to-accent text-primary-foreground shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/25"
                  onClick={() => {
                    setRegionId(undefined);
                    setCommodity(undefined);
                    setThreshold(60);
                    setLayer("ndvi");
                    setDateRange("30d");
                  }}
                  data-testid="reset-filters"
                >
                  Reset
                </Button>
              </div>
            </div>

            <div className="p-5">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2" data-testid="kpi-grid">
                <MetricCard
                  label="Crop health score"
                  value={summaryQ.isLoading ? <Skeleton className="h-7 w-24 rounded-xl bg-muted/30" /> : safeNum(kpis?.cropHealthScore, 0)}
                  deltaPct={trends?.cropHealthDeltaPct ?? null}
                  tone="primary"
                  icon={<Leaf className="h-5 w-5" />}
                  testId="kpi-cropHealthScore"
                />
                <MetricCard
                  label="Climate risk index"
                  value={summaryQ.isLoading ? <Skeleton className="h-7 w-24 rounded-xl bg-muted/30" /> : safeNum(kpis?.climateRiskIndex, 0)}
                  deltaPct={trends?.climateRiskDeltaPct ?? null}
                  tone="danger"
                  icon={<AlertTriangle className="h-5 w-5" />}
                  testId="kpi-climateRiskIndex"
                />
                <MetricCard
                  label="Water stress"
                  value={summaryQ.isLoading ? <Skeleton className="h-7 w-24 rounded-xl bg-muted/30" /> : fmtPct(kpis?.waterStressPct ?? 0)}
                  deltaPct={trends?.waterStressDeltaPct ?? null}
                  tone="warn"
                  icon={<Droplets className="h-5 w-5" />}
                  testId="kpi-waterStressPct"
                />
                <MetricCard
                  label="Flood watch"
                  value={summaryQ.isLoading ? <Skeleton className="h-7 w-24 rounded-xl bg-muted/30" /> : `${kpis?.floodWatchCount ?? 0}`}
                  deltaPct={trends?.floodWatchDeltaPct ?? null}
                  tone="accent"
                  icon={<Waves className="h-5 w-5" />}
                  testId="kpi-floodWatchCount"
                />
              </div>

              <Separator className="my-5 bg-border/60" />

              <Tabs defaultValue="alerts" className="w-full">
                <TabsList className="grid w-full grid-cols-3 rounded-2xl border border-border/70 bg-card/35 p-1">
                  <TabsTrigger value="alerts" className="rounded-xl" data-testid="tab-alerts">
                    Alerts
                  </TabsTrigger>
                  <TabsTrigger value="analytics" className="rounded-xl" data-testid="tab-analytics">
                    Analytics
                  </TabsTrigger>
                  <TabsTrigger value="stats" className="rounded-xl" data-testid="tab-stats">
                    Stats
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="alerts" className="mt-4" data-testid="alerts-panel">
                  <Card className="rounded-3xl border-border/70 bg-card/35 p-4">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <ShieldAlert className="h-4 w-4 text-primary" />
                        <div className="text-sm font-extrabold tracking-tight" id="alerts">
                          Recent alerts
                        </div>
                      </div>
                      <Badge
                        className="rounded-full border border-border/70 bg-card/60 px-3 py-1 text-xs"
                        data-testid="alerts-count"
                      >
                        {alertsQ.isLoading ? "…" : `${alerts.length}`}
                      </Badge>
                    </div>

                    <div className="mt-3 max-h-[320px] space-y-2 overflow-auto pr-1 scrollbar-slim">
                      {alertsQ.isLoading ? (
                        <div className="space-y-2">
                          {Array.from({ length: 6 }).map((_, i) => (
                            <Skeleton key={i} className="h-14 w-full rounded-2xl bg-muted/30" />
                          ))}
                        </div>
                      ) : alerts.length === 0 ? (
                        <div className="rounded-2xl border border-border/70 bg-background/20 p-6 text-center">
                          <div className="text-sm font-semibold">No alerts for this scope</div>
                          <div className="mt-1 text-sm text-muted-foreground">
                            Try lowering the threshold or switching to a longer range.
                          </div>
                        </div>
                      ) : (
                        alerts.slice(0, 50).map((a) => (
                          <button
                            key={a.id}
                            className="group w-full rounded-2xl border border-border/70 bg-background/20 p-3 text-left transition-all duration-300 hover:-translate-y-0.5 hover:bg-card/40 focus:outline-none focus-visible:ring-4 focus-visible:ring-primary/15"
                            onClick={() => {
                              const fid = a.fieldId ?? null;
                              if (fid) {
                                setSelectedFieldId(fid);
                                setDetailsOpen(true);
                              } else {
                                toast({
                                  title: "No field linked",
                                  description: "This alert is region-level or missing fieldId.",
                                });
                              }
                            }}
                            data-testid={`alert-row-${a.id}`}
                          >
                            <div className="flex items-start justify-between gap-3">
                              <div className="min-w-0">
                                <div className="flex flex-wrap items-center gap-2">
                                  <SeverityBadge severity={a.severity} />
                                  <span className="text-sm font-extrabold tracking-tight">
                                    {a.type}
                                  </span>
                                  {a.fieldId ? (
                                    <Badge
                                      variant="secondary"
                                      className="rounded-full border border-border/70 bg-card/50"
                                    >
                                      Field {a.fieldId.slice(0, 6)}…
                                    </Badge>
                                  ) : null}
                                </div>
                                <div className="mt-1 line-clamp-2 text-sm text-muted-foreground">
                                  {a.message}
                                </div>
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {new Date(a.occurredAt).toLocaleString()}
                              </div>
                            </div>
                          </button>
                        ))
                      )}
                    </div>
                  </Card>
                </TabsContent>

                <TabsContent value="analytics" className="mt-4" data-testid="analytics-panel">
                  <Card className="rounded-3xl border-border/70 bg-card/35 p-4" id="analytics">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <Activity className="h-4 w-4 text-primary" />
                        <div className="text-sm font-extrabold tracking-tight">Alert intensity</div>
                      </div>
                      <Badge className="rounded-full border border-border/70 bg-card/60 px-3 py-1 text-xs">
                        Derived
                      </Badge>
                    </div>

                    <div className="mt-3 h-56">
                      {alertsQ.isLoading ? (
                        <Skeleton className="h-full w-full rounded-2xl bg-muted/30" />
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart data={analyticsSeries} margin={{ left: 6, right: 10, top: 10, bottom: 0 }}>
                            <defs>
                              <linearGradient id="riskStroke" x1="0" x2="1">
                                <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={1} />
                                <stop offset="50%" stopColor="hsl(var(--accent))" stopOpacity={1} />
                                <stop offset="100%" stopColor="hsl(var(--destructive))" stopOpacity={0.95} />
                              </linearGradient>
                            </defs>
                            <CartesianGrid stroke="hsl(var(--border) / 0.6)" strokeDasharray="4 6" />
                            <XAxis
                              dataKey="i"
                              tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
                              axisLine={{ stroke: "hsl(var(--border) / 0.7)" }}
                              tickLine={{ stroke: "hsl(var(--border) / 0.7)" }}
                            />
                            <YAxis
                              domain={[0, 100]}
                              tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
                              axisLine={{ stroke: "hsl(var(--border) / 0.7)" }}
                              tickLine={{ stroke: "hsl(var(--border) / 0.7)" }}
                            />
                            <ReTooltip
                              contentStyle={{
                                background: "hsl(var(--popover) / 0.92)",
                                border: "1px solid hsl(var(--border) / 0.8)",
                                borderRadius: 16,
                                boxShadow: "0 18px 50px rgba(0,0,0,.55)",
                              }}
                              labelFormatter={(l) => `Event ${l}`}
                            />
                            <Line
                              type="monotone"
                              dataKey="severity"
                              stroke="url(#riskStroke)"
                              strokeWidth={2.4}
                              dot={false}
                            />
                          </LineChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </Card>
                </TabsContent>

                <TabsContent value="stats" className="mt-4" data-testid="stats-panel">
                  <Card className="rounded-3xl border-border/70 bg-card/35 p-4">
                    <div className="flex items-center gap-2">
                      <MapPinned className="h-4 w-4 text-primary" />
                      <div className="text-sm font-extrabold tracking-tight">Scope stats</div>
                    </div>

                    <div className="mt-3 grid grid-cols-2 gap-3">
                      <div className="rounded-2xl border border-border/70 bg-background/20 p-3">
                        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                          Fields
                        </div>
                        <div className="mt-1 text-xl font-extrabold" data-testid="stat-fieldsCount">
                          {summaryQ.isLoading ? "…" : `${stats?.fieldsCount ?? 0}`}
                        </div>
                      </div>
                      <div className="rounded-2xl border border-border/70 bg-background/20 p-3">
                        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                          Regions
                        </div>
                        <div className="mt-1 text-xl font-extrabold" data-testid="stat-regionsCount">
                          {summaryQ.isLoading ? "…" : `${stats?.regionsCount ?? 0}`}
                        </div>
                      </div>
                      <div className="rounded-2xl border border-border/70 bg-background/20 p-3">
                        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                          Stressed fields
                        </div>
                        <div className="mt-1 text-xl font-extrabold" data-testid="stat-stressedFieldsCount">
                          {summaryQ.isLoading ? "…" : `${stats?.stressedFieldsCount ?? 0}`}
                        </div>
                      </div>
                      <div className="rounded-2xl border border-border/70 bg-background/20 p-3">
                        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                          High risk
                        </div>
                        <div className="mt-1 text-xl font-extrabold" data-testid="stat-highRiskFieldsCount">
                          {summaryQ.isLoading ? "…" : `${stats?.highRiskFieldsCount ?? 0}`}
                        </div>
                      </div>
                    </div>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </motion.div>

          {/* RIGHT PANEL (MAP) */}
          <motion.div
            className="lg:col-span-8"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.05, ease: [0.2, 0.9, 0.2, 1] }}
            data-testid="right-panel"
          >
            <div className="mb-4 grid gap-3 md:grid-cols-2">
              <Card className="glass-panel rounded-3xl p-4">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <ThermometerSun className="h-4 w-4 text-[hsl(var(--chart-3))]" />
                    <div className="text-sm font-extrabold tracking-tight">Selected field trend</div>
                  </div>
                  <Badge className="rounded-full border border-border/70 bg-card/55 px-3 py-1 text-xs" data-testid="selected-field-badge">
                    {selectedFieldId ? `${selectedFieldId.slice(0, 8)}…` : "None"}
                  </Badge>
                </div>

                <div className="mt-3 h-40">
                  {!selectedFieldId ? (
                    <div className="flex h-full items-center justify-center rounded-2xl border border-border/70 bg-background/20 text-center text-sm text-muted-foreground">
                      Click a field on the map to preview NDVI & risk.
                    </div>
                  ) : metricsQ.isLoading ? (
                    <Skeleton className="h-full w-full rounded-2xl bg-muted/30" />
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={sparkSeries} margin={{ left: 0, right: 0, top: 10, bottom: 0 }}>
                        <CartesianGrid stroke="hsl(var(--border) / 0.6)" strokeDasharray="4 6" />
                        <XAxis
                          dataKey="date"
                          tickFormatter={dateTick}
                          tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }}
                          axisLine={{ stroke: "hsl(var(--border) / 0.7)" }}
                          tickLine={{ stroke: "hsl(var(--border) / 0.7)" }}
                          minTickGap={22}
                        />
                        <YAxis
                          domain={[0, 1]}
                          tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }}
                          axisLine={{ stroke: "hsl(var(--border) / 0.7)" }}
                          tickLine={{ stroke: "hsl(var(--border) / 0.7)" }}
                        />
                        <ReTooltip
                          contentStyle={{
                            background: "hsl(var(--popover) / 0.92)",
                            border: "1px solid hsl(var(--border) / 0.8)",
                            borderRadius: 16,
                            boxShadow: "0 18px 50px rgba(0,0,0,.55)",
                          }}
                          labelFormatter={(l) => String(l)}
                        />
                        <Line type="monotone" dataKey="ndvi" stroke="hsl(var(--primary))" strokeWidth={2.2} dot={false} />
                        <Line type="monotone" dataKey="risk" stroke="hsl(var(--destructive))" strokeWidth={1.6} dot={false} />
                      </LineChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </Card>

              <Card className="glass-panel rounded-3xl p-4">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <Waves className="h-4 w-4 text-[hsl(var(--chart-2))]" />
                    <div className="text-sm font-extrabold tracking-tight" id="layers">
                      Layer notes
                    </div>
                  </div>
                  <Badge className="rounded-full border border-border/70 bg-card/55 px-3 py-1 text-xs">
                    {showRaster ? "Tiles on" : "Tiles off"}
                  </Badge>
                </div>

                <div className="mt-3 space-y-2 text-sm text-muted-foreground">
                  <div className="rounded-2xl border border-border/70 bg-background/20 p-3">
                    <span className="font-semibold text-foreground">NDVI</span> emphasizes vegetation vigor;{" "}
                    <span className="text-primary">higher is healthier</span>.
                  </div>
                  <div className="rounded-2xl border border-border/70 bg-background/20 p-3">
                    <span className="font-semibold text-foreground">Risk layers</span> surface potential flooding or stress patterns.
                    Pair with alerts to prioritize scouting.
                  </div>
                </div>
              </Card>
            </div>

            <DtMap
              geojson={showFields ? fieldsQ.data : undefined}
              selectedFieldId={selectedFieldId}
              onSelectField={(id) => {
                setSelectedFieldId(id);
                setDetailsOpen(true);
              }}
              layer={layer}
              lastAlert={lastAlert}
              highlightedFieldId={lastAlert?.fieldId ?? null}
              className="h-[800px] w-full bg-card/20 shadow-2xl shadow-black/50"
            />
          </motion.div>
        </div>

        <FieldDetailsDialog
          open={detailsOpen}
          onOpenChange={(v) => {
            setDetailsOpen(v);
            if (!v) setSelectedFieldId(null);
          }}
          data={metricsQ.data ?? null}
          isLoading={metricsQ.isLoading}
          isError={metricsQ.isError}
          onRetry={() => metricsQ.refetch()}
        />
      </div>
    </AppShell>
  );
}
