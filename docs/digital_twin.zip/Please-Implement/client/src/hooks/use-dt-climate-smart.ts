import { useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, ws } from "@shared/routes";
import type {
  DtAlertItem,
  DtAlertsWsMessage,
  DtLayer,
  DateRange,
} from "@shared/schema";
import { z } from "zod";

function parseWithLogging<T>(schema: z.ZodSchema<T>, data: unknown, label: string): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    console.error(`[Zod] ${label} validation failed:`, result.error.format());
    throw result.error;
  }
  return result.data;
}

function buildQueryString(input?: Record<string, unknown>) {
  if (!input) return "";
  const params = new URLSearchParams();
  Object.entries(input).forEach(([k, v]) => {
    if (v === undefined || v === null) return;
    params.set(k, String(v));
  });
  const qs = params.toString();
  return qs ? `?${qs}` : "";
}

export type SummaryFilters = {
  dateRange: DateRange;
  regionId?: string;
  commodity?: string;
};

export function useDtSummary(filters: SummaryFilters) {
  return useQuery({
    queryKey: [api.digitalTwinClimateSmart.summary.path, filters],
    queryFn: async () => {
      const validated = parseWithLogging(
        api.digitalTwinClimateSmart.summary.input ?? z.any(),
        filters,
        "digitalTwinClimateSmart.summary.input",
      );
      const url = `${api.digitalTwinClimateSmart.summary.path}${buildQueryString(validated)}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error(`Failed to fetch summary (${res.status})`);
      const json = await res.json();
      return parseWithLogging(
        api.digitalTwinClimateSmart.summary.responses[200],
        json,
        "digitalTwinClimateSmart.summary.responses[200]",
      );
    },
  });
}

export type FieldsFilters = {
  regionId?: string;
  commodity?: string;
};

export function useDtFieldsGeoJson(filters: FieldsFilters) {
  return useQuery({
    queryKey: [api.digitalTwinClimateSmart.fields.path, filters],
    queryFn: async () => {
      const validated = parseWithLogging(
        api.digitalTwinClimateSmart.fields.input ?? z.any(),
        filters,
        "digitalTwinClimateSmart.fields.input",
      );
      const url = `${api.digitalTwinClimateSmart.fields.path}${buildQueryString(validated)}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error(`Failed to fetch fields (${res.status})`);
      const json = await res.json();
      return parseWithLogging(
        api.digitalTwinClimateSmart.fields.responses[200],
        json,
        "digitalTwinClimateSmart.fields.responses[200]",
      );
    },
  });
}

export type FieldMetricsFilters = {
  dateRange: DateRange;
};

export function useDtFieldMetrics(fieldId?: string | null, filters?: FieldMetricsFilters) {
  return useQuery({
    queryKey: [api.digitalTwinClimateSmart.fieldMetrics.path, fieldId, filters],
    enabled: !!fieldId,
    queryFn: async () => {
      const urlBase = buildUrl(api.digitalTwinClimateSmart.fieldMetrics.path, { id: String(fieldId) });
      const validated = parseWithLogging(
        api.digitalTwinClimateSmart.fieldMetrics.input ?? z.any(),
        filters ?? { dateRange: "30d" },
        "digitalTwinClimateSmart.fieldMetrics.input",
      );
      const url = `${urlBase}${buildQueryString(validated)}`;
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error(`Failed to fetch field metrics (${res.status})`);
      const json = await res.json();
      return parseWithLogging(
        api.digitalTwinClimateSmart.fieldMetrics.responses[200],
        json,
        "digitalTwinClimateSmart.fieldMetrics.responses[200]",
      );
    },
  });
}

export type AlertsFilters = {
  dateRange: DateRange;
  threshold: number;
  regionId?: string;
};

export function useDtAlerts(filters: AlertsFilters) {
  return useQuery({
    queryKey: [api.digitalTwinClimateSmart.alerts.path, filters],
    queryFn: async () => {
      const validated = parseWithLogging(
        api.digitalTwinClimateSmart.alerts.input ?? z.any(),
        filters,
        "digitalTwinClimateSmart.alerts.input",
      );
      const url = `${api.digitalTwinClimateSmart.alerts.path}${buildQueryString(validated)}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error(`Failed to fetch alerts (${res.status})`);
      const json = await res.json();
      return parseWithLogging(
        api.digitalTwinClimateSmart.alerts.responses[200],
        json,
        "digitalTwinClimateSmart.alerts.responses[200]",
      );
    },
  });
}

export function useTileUrl(layer: DtLayer, zVal: number, x: number, y: number, date?: string) {
  return useMemo(() => {
    const base = buildUrl(api.digitalTwinClimateSmart.tiles.path, {
      layer,
      z: zVal,
      x,
      y,
    });
    const qs = buildQueryString(date ? { date } : undefined);
    return `${base}${qs}`;
  }, [layer, zVal, x, y, date]);
}

/**
 * WebSocket hook for dt-alerts channel.
 * - Connects to same-origin /ws (ws or wss based on page protocol)
 * - Sends hello on open
 * - Validates incoming payloads via @shared/routes ws.receive schemas
 */
export function useDtAlertsWebSocket() {
  const queryClient = useQueryClient();
  const [connected, setConnected] = useState(false);
  const [lastAlert, setLastAlert] = useState<DtAlertItem | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const retryRef = useRef(0);
  const aliveRef = useRef(true);

  useEffect(() => {
    aliveRef.current = true;

    const connect = () => {
      const proto = window.location.protocol === "https:" ? "wss" : "ws";
      const url = `${proto}://${window.location.host}/ws`;
      const sock = new WebSocket(url);
      wsRef.current = sock;

      sock.onopen = () => {
        retryRef.current = 0;
        setConnected(true);
        sock.send(JSON.stringify({ type: "hello", channel: "dt-alerts" }));
      };

      sock.onclose = () => {
        setConnected(false);
        if (!aliveRef.current) return;

        retryRef.current += 1;
        const delay = Math.min(12000, 400 * 2 ** retryRef.current);
        window.setTimeout(() => {
          if (aliveRef.current) connect();
        }, delay);
      };

      sock.onerror = () => {
        // let onclose handle reconnect
      };

      sock.onmessage = (evt) => {
        try {
          const raw = JSON.parse(evt.data) as DtAlertsWsMessage;
          // Validate with shared schemas
          const type = (raw as any)?.type;
          if (type === "hello") {
            parseWithLogging(ws.receive.hello, raw, "ws.receive.hello");
            return;
          }
          if (type === "alert") {
            const msg = parseWithLogging(ws.receive.alert, raw, "ws.receive.alert");
            setLastAlert(msg.payload as unknown as DtAlertItem);

            // Optimistically update alerts cache by prepending
            queryClient.setQueriesData(
              { queryKey: [api.digitalTwinClimateSmart.alerts.path] },
              (prev: any) => {
                if (!prev?.items) return prev;
                const items = [msg.payload, ...prev.items];
                // Keep list from exploding
                return { ...prev, items: items.slice(0, 250) };
              },
            );
            return;
          }
          if (type === "alerts") {
            const msg = parseWithLogging(ws.receive.alerts, raw, "ws.receive.alerts");
            // Replace alerts list if server sends full list
            queryClient.setQueriesData(
              { queryKey: [api.digitalTwinClimateSmart.alerts.path] },
              (prev: any) => {
                if (!prev) return { items: msg.payload.items };
                return { ...prev, items: msg.payload.items };
              },
            );
            return;
          }
        } catch (e) {
          console.error("[WS] Failed to parse/validate message:", e);
        }
      };
    };

    connect();
    return () => {
      aliveRef.current = false;
      try {
        wsRef.current?.close();
      } catch {
        // ignore
      }
    };
  }, [queryClient]);

  return { connected, lastAlert };
}

/**
 * Utility mutation purely to invalidate all DT queries (useful after "Refresh" button).
 */
export function useInvalidateDigitalTwin() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      return true;
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({
        queryKey: [api.digitalTwinClimateSmart.summary.path],
      });
      await queryClient.invalidateQueries({
        queryKey: [api.digitalTwinClimateSmart.fields.path],
      });
      await queryClient.invalidateQueries({
        queryKey: [api.digitalTwinClimateSmart.alerts.path],
      });
      await queryClient.invalidateQueries({
        queryKey: [api.digitalTwinClimateSmart.fieldMetrics.path],
      });
    },
  });
}
