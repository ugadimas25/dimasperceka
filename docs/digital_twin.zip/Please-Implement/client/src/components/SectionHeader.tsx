import { ReactNode } from "react";
import { cn } from "@/lib/utils";

export default function SectionHeader({
  title,
  subtitle,
  right,
  testId,
}: {
  title: string;
  subtitle?: string;
  right?: ReactNode;
  testId?: string;
}) {
  return (
    <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between" data-testid={testId}>
      <div className="min-w-0">
        <h1 className={cn("text-2xl font-extrabold tracking-tight sm:text-3xl")}>
          {title}
        </h1>
        {subtitle ? (
          <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{subtitle}</p>
        ) : null}
      </div>
      {right ? <div className="flex items-center gap-2">{right}</div> : null}
    </div>
  );
}
