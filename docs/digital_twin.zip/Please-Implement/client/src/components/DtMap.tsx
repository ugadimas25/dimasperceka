import "maplibre-gl/dist/maplibre-gl.css";

import { useEffect, useMemo, useRef } from "react";
import Map, { Source, Layer, Popup } from "react-map-gl/maplibre";
import type { MapRef, MapLayerMouseEvent } from "react-map-gl/maplibre";
import type { DtLayer, DtFieldsGeoJson, DtAlertItem } from "@shared/schema";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import SeverityBadge from "@/components/SeverityBadge";

type Props = {
  geojson?: DtFieldsGeoJson;
  selectedFieldId?: string | null;
  onSelectField: (id: string) => void;
  layer: DtLayer;
  tileDate?: string;
  highlightedFieldId?: string | null;
  lastAlert?: DtAlertItem | null;
  className?: string;
};

function getFillColorExpr(layer: DtLayer) {
  // Color based on available properties; in absence, fallback.
  // Expression uses properties fields: latestNdvi, waterStressIdx, floodRiskIdx
  if (layer === "ndvi") {
    // NDVI: low=red, mid=amber, high=green
    return [
      "case",
      ["==", ["get", "latestNdvi"], null],
      "rgba(255,255,255,0.06)",
      ["<", ["get", "latestNdvi"], 0.3],
      "rgba(239,68,68,0.45)",
      ["<", ["get", "latestNdvi"], 0.6],
      "rgba(245,158,11,0.38)",
      "rgba(16,185,129,0.36)",
    ];
  }
  if (layer === "water_stress") {
    return [
      "case",
      ["==", ["get", "waterStressIdx"], null],
      "rgba(255,255,255,0.06)",
      [">", ["get", "waterStressIdx"], 0.75],
      "rgba(239,68,68,0.42)",
      [">", ["get", "waterStressIdx"], 0.5],
      "rgba(245,158,11,0.36)",
      "rgba(56,189,248,0.28)",
    ];
  }
  if (layer === "flood_risk") {
    return [
      "case",
      ["==", ["get", "floodRiskIdx"], null],
      "rgba(255,255,255,0.06)",
      [">", ["get", "floodRiskIdx"], 0.75],
      "rgba(239,68,68,0.40)",
      [">", ["get", "floodRiskIdx"], 0.5],
      "rgba(245,158,11,0.34)",
      "rgba(34,211,238,0.26)",
    ];
  }
  // anomaly layers are served as raster tiles; polygon is neutral
  return "rgba(255,255,255,0.06)";
}

export default function DtMap({
  geojson,
  selectedFieldId,
  onSelectField,
  layer,
  lastAlert,
  highlightedFieldId,
  className,
}: Props) {
  const mapRef = useRef<MapRef | null>(null);
  const hoveredIdRef = useRef<string | null>(null);

  const initialView = useMemo(
    () => ({
      longitude: -93.2,
      latitude: 44.95,
      zoom: 8.4,
      pitch: 0,
      bearing: 0,
    }),
    [],
  );

  const fillLayer: any = useMemo(
    () => ({
      id: "fields-fill",
      type: "fill",
      paint: {
        "fill-color": getFillColorExpr(layer),
        "fill-opacity": [
          "case",
          ["==", ["get", "id"], selectedFieldId ?? ""],
          0.62,
          ["==", ["get", "id"], highlightedFieldId ?? ""],
          0.62,
          0.34,
        ],
      },
    }),
    [layer, selectedFieldId, highlightedFieldId],
  );

  const lineLayer: any = useMemo(
    () => ({
      id: "fields-line",
      type: "line",
      paint: {
        "line-color": [
          "case",
          ["==", ["get", "id"], selectedFieldId ?? ""],
          "rgba(16,185,129,0.95)",
          ["==", ["get", "id"], highlightedFieldId ?? ""],
          "rgba(56,189,248,0.95)",
          "rgba(148,163,184,0.40)",
        ],
        "line-width": [
          "case",
          ["==", ["get", "id"], selectedFieldId ?? ""],
          2.4,
          ["==", ["get", "id"], highlightedFieldId ?? ""],
          2.2,
          1.2,
        ],
      },
    }),
    [selectedFieldId, highlightedFieldId],
  );

  const [popup, setPopup] = useMemo(() => {
    // simple state-like tuple without introducing React state,
    // but we need rerender: useEffect triggers on select; for hover use state.
    return [null as any, null as any];
  }, []);

  // On new alert, fly to field if possible
  useEffect(() => {
    const fid = lastAlert?.fieldId ?? null;
    if (!fid || !geojson) return;
    // Attempt to find feature centroid-ish: use bbox from coordinates
    const f = geojson.features.find((x) => x.properties.id === fid);
    const coords = (f as any)?.geometry?.coordinates;
    if (!coords) return;
    // naive centroid: pick first coordinate
    const first = Array.isArray(coords) ? coords[0]?.[0]?.[0] ?? coords[0]?.[0] : null;
    if (!first || !Array.isArray(first)) return;
    const [lng, lat] = first as [number, number];
    mapRef.current?.flyTo({ center: [lng, lat], zoom: Math.max(mapRef.current?.getZoom() ?? 9, 11), duration: 900 });
  }, [lastAlert, geojson]);

  const onClick = (e: MapLayerMouseEvent) => {
    const feature = e.features?.[0];
    const id = (feature as any)?.properties?.id as string | undefined;
    if (id) onSelectField(id);
  };

  const onMove = (e: MapLayerMouseEvent) => {
    const feature = e.features?.[0];
    const id = (feature as any)?.properties?.id as string | undefined;
    hoveredIdRef.current = id ?? null;
  };

  const interactiveLayerIds = useMemo(() => ["fields-fill"], []);

  const mapStyle = "https://demotiles.maplibre.org/style.json";

  return (
    <div className={cn("relative overflow-hidden rounded-3xl border border-border/70", className)} data-testid="dt-map-container">
      <div className="pointer-events-none absolute inset-0 z-10 bg-gradient-to-t from-background/70 via-transparent to-transparent" />

      <Map
        ref={mapRef}
        mapLib={undefined as any}
        initialViewState={initialView}
        mapStyle={mapStyle}
        attributionControl={false}
        interactiveLayerIds={interactiveLayerIds}
        onClick={onClick}
        onMouseMove={onMove}
        cursor="crosshair"
      >
        {geojson ? (
          <Source id="fields" type="geojson" data={geojson as any}>
            <Layer {...fillLayer} />
            <Layer {...lineLayer} />
          </Source>
        ) : null}
      </Map>

      <div className="absolute left-4 top-4 z-20 flex flex-wrap items-center gap-2">
        <Badge
          className="rounded-full border border-border/70 bg-card/60 px-3 py-1 text-xs font-semibold text-foreground shadow-sm"
          data-testid="map-layer-badge"
        >
          Layer: <span className="ml-1 text-primary">{layer}</span>
        </Badge>

        {highlightedFieldId ? (
          <Badge className="rounded-full border border-accent/30 bg-accent/10 px-3 py-1 text-xs font-semibold text-accent-foreground">
            Highlighted: {highlightedFieldId.slice(0, 6)}…
          </Badge>
        ) : null}

        {lastAlert ? (
          <span className="inline-flex items-center gap-2 rounded-full border border-border/70 bg-card/60 px-3 py-1 shadow-sm">
            <SeverityBadge severity={lastAlert.severity} />
            <span className="max-w-[220px] truncate text-xs font-semibold text-foreground/90">
              {lastAlert.type}
            </span>
          </span>
        ) : null}
      </div>

      <div className="absolute bottom-4 right-4 z-20">
        <div className="rounded-2xl border border-border/70 bg-card/55 px-3 py-2 text-xs text-muted-foreground shadow-lg shadow-black/40 backdrop-blur-md">
          Click field polygons for details
        </div>
      </div>
    </div>
  );
}
