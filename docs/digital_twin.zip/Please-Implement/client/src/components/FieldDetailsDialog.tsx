import { useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { X, Leaf, Droplets, Waves, ThermometerSun } from "lucide-react";
import { ResponsiveContainer, Area, AreaChart, CartesianGrid, Tooltip, XAxis, YAxis } from "recharts";
import type { DtFieldMetricsResponse } from "@shared/schema";
import SeverityBadge from "@/components/SeverityBadge";

function formatDateTick(v: string) {
  // v expected ISO-ish date string
  try {
    return new Date(v).toLocaleDateString(undefined, { month: "short", day: "numeric" });
  } catch {
    return v;
  }
}

export default function FieldDetailsDialog({
  open,
  onOpenChange,
  data,
  isLoading,
  isError,
  onRetry,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  data: DtFieldMetricsResponse | null | undefined;
  isLoading: boolean;
  isError: boolean;
  onRetry: () => void;
}) {
  const series = data?.series ?? [];

  const ndviSeries = useMemo(() => {
    return series.map((d) => ({
      date: d.date,
      ndvi: d.ndvi ?? null,
      riskScore: d.riskScore,
      water: d.waterStressIdx ?? null,
      flood: d.floodRiskIdx ?? null,
      rain: d.rainfallMm ?? null,
      temp: d.tempC ?? null,
    }));
  }, [series]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="max-w-3xl overflow-hidden rounded-3xl border border-border/70 bg-gradient-to-b from-card/80 to-card/60 p-0 shadow-2xl shadow-black/60"
        data-testid="field-details-dialog"
      >
        <div className="flex items-start justify-between gap-3 border-b border-border/70 p-5">
          <DialogHeader className="space-y-1">
            <DialogTitle className="text-xl font-extrabold tracking-tight">
              {data?.field?.name ?? (isLoading ? "Loading field…" : "Field details")}
            </DialogTitle>
            <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
              <span className="inline-flex items-center gap-2">
                <Badge variant="secondary" className="rounded-full border border-border/70 bg-card/50">
                  {data?.field?.commodity ?? "—"}
                </Badge>
                <span className="text-xs">Region</span>
                <span className="font-semibold text-foreground/90">
                  {data?.field?.regionId ?? "—"}
                </span>
              </span>
            </div>
          </DialogHeader>

          <Button
            variant="ghost"
            className="h-10 w-10 rounded-2xl"
            onClick={() => onOpenChange(false)}
            data-testid="field-details-close"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="grid gap-5 p-5 md:grid-cols-3">
          <div className="md:col-span-2">
            <div className="rounded-2xl border border-border/70 bg-background/30 p-4">
              <div className="flex items-center justify-between gap-2">
                <div className="text-sm font-bold tracking-tight">NDVI trend</div>
                <div className="text-xs text-muted-foreground">Normalized Difference Vegetation Index</div>
              </div>

              <div className="mt-3 h-56">
                {isLoading ? (
                  <div className="h-full w-full">
                    <Skeleton className="h-full w-full rounded-2xl bg-muted/30" />
                  </div>
                ) : isError ? (
                  <div className="flex h-full items-center justify-center rounded-2xl border border-border/70 bg-card/40 p-6 text-center">
                    <div>
                      <div className="text-sm font-semibold">Failed to load field metrics</div>
                      <div className="mt-1 text-sm text-muted-foreground">
                        Try again — the backend may still be warming up.
                      </div>
                      <Button
                        className="mt-4 rounded-xl"
                        onClick={onRetry}
                        data-testid="field-details-retry"
                      >
                        Retry
                      </Button>
                    </div>
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={ndviSeries} margin={{ left: 6, right: 10, top: 10, bottom: 0 }}>
                      <defs>
                        <linearGradient id="ndviFill" x1="0" x2="0" y1="0" y2="1">
                          <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.35} />
                          <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0.02} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid stroke="hsl(var(--border) / 0.6)" strokeDasharray="4 6" />
                      <XAxis
                        dataKey="date"
                        tickFormatter={formatDateTick}
                        tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
                        axisLine={{ stroke: "hsl(var(--border) / 0.7)" }}
                        tickLine={{ stroke: "hsl(var(--border) / 0.7)" }}
                        minTickGap={24}
                      />
                      <YAxis
                        domain={[0, 1]}
                        tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
                        axisLine={{ stroke: "hsl(var(--border) / 0.7)" }}
                        tickLine={{ stroke: "hsl(var(--border) / 0.7)" }}
                      />
                      <Tooltip
                        contentStyle={{
                          background: "hsl(var(--popover) / 0.92)",
                          border: "1px solid hsl(var(--border) / 0.8)",
                          borderRadius: 16,
                          boxShadow: "0 18px 50px rgba(0,0,0,.55)",
                        }}
                        labelStyle={{ color: "hsl(var(--foreground))", fontWeight: 700 }}
                      />
                      <Area
                        type="monotone"
                        dataKey="ndvi"
                        stroke="hsl(var(--primary))"
                        strokeWidth={2.4}
                        fill="url(#ndviFill)"
                        dot={false}
                        activeDot={{ r: 5, strokeWidth: 2, stroke: "hsl(var(--background))" }}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                )}
              </div>
            </div>

            <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div className="rounded-2xl border border-border/70 bg-card/40 p-3">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  <Leaf className="h-4 w-4 text-primary" />
                  NDVI avg
                </div>
                <div className="mt-1 text-lg font-extrabold">
                  {data?.summary?.ndviAvg ?? "—"}
                </div>
              </div>

              <div className="rounded-2xl border border-border/70 bg-card/40 p-3">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  <Droplets className="h-4 w-4 text-[hsl(var(--chart-2))]" />
                  Rain total
                </div>
                <div className="mt-1 text-lg font-extrabold">
                  {data?.summary?.rainfallTotalMm !== null && data?.summary?.rainfallTotalMm !== undefined
                    ? `${data.summary.rainfallTotalMm.toFixed(0)} mm`
                    : "—"}
                </div>
              </div>

              <div className="rounded-2xl border border-border/70 bg-card/40 p-3">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  <ThermometerSun className="h-4 w-4 text-[hsl(var(--chart-3))]" />
                  Temp avg
                </div>
                <div className="mt-1 text-lg font-extrabold">
                  {data?.summary?.tempAvgC !== null && data?.summary?.tempAvgC !== undefined
                    ? `${data.summary.tempAvgC.toFixed(1)}°C`
                    : "—"}
                </div>
              </div>
            </div>
          </div>

          <div className="md:col-span-1">
            <div className="rounded-2xl border border-border/70 bg-card/40 p-4">
              <div className="text-sm font-bold tracking-tight">Current risk badges</div>
              <div className="mt-3 flex flex-wrap gap-2">
                {isLoading ? (
                  <>
                    <Skeleton className="h-7 w-24 rounded-full bg-muted/30" />
                    <Skeleton className="h-7 w-32 rounded-full bg-muted/30" />
                    <Skeleton className="h-7 w-20 rounded-full bg-muted/30" />
                  </>
                ) : (
                  (data?.summary?.currentRiskBadges ?? []).map((b, idx) => (
                    <span key={`${b.type}-${idx}`} className="inline-flex items-center gap-2">
                      <SeverityBadge severity={b.severity} />
                      <span className="text-xs font-semibold text-muted-foreground">{b.label}</span>
                    </span>
                  ))
                )}

                {!isLoading && (data?.summary?.currentRiskBadges?.length ?? 0) === 0 ? (
                  <div className="text-sm text-muted-foreground">
                    No active risk badges detected for this range.
                  </div>
                ) : null}
              </div>
            </div>

            <div className="mt-4 rounded-2xl border border-border/70 bg-card/40 p-4">
              <div className="flex items-center gap-2 text-sm font-bold tracking-tight">
                <Waves className="h-4 w-4 text-[hsl(var(--chart-2))]" />
                Stress indices
              </div>
              <div className="mt-3 grid gap-3">
                <div className="rounded-xl border border-border/60 bg-background/20 p-3">
                  <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Water stress max
                  </div>
                  <div className="mt-1 text-lg font-extrabold">
                    {data?.summary?.waterStressMax ?? "—"}
                  </div>
                </div>
                <div className="rounded-xl border border-border/60 bg-background/20 p-3">
                  <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Flood risk max
                  </div>
                  <div className="mt-1 text-lg font-extrabold">
                    {data?.summary?.floodRiskMax ?? "—"}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
