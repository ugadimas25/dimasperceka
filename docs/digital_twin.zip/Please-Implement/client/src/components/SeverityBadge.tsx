import { cn } from "@/lib/utils";
import type { AlertSeverity } from "@shared/schema";

const styles: Record<AlertSeverity, string> = {
  low: "border-emerald-400/20 bg-emerald-400/10 text-emerald-200",
  medium: "border-sky-400/20 bg-sky-400/10 text-sky-200",
  high: "border-amber-400/25 bg-amber-400/10 text-amber-200",
  critical: "border-red-400/25 bg-red-500/10 text-red-200",
};

export default function SeverityBadge({ severity, className }: { severity: AlertSeverity; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs font-semibold tracking-tight",
        styles[severity],
        className,
      )}
      data-testid={`severity-${severity}`}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current opacity-80" />
      {severity.toUpperCase()}
    </span>
  );
}
