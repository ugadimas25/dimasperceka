import { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { ArrowDownRight, ArrowUpRight } from "lucide-react";

export type MetricTone = "primary" | "accent" | "warn" | "danger";

const toneStyles: Record<MetricTone, { ring: string; glow: string; chip: string }> = {
  primary: {
    ring: "ring-primary/20",
    glow: "shadow-[0_18px_60px_-20px] shadow-primary/30",
    chip: "bg-primary/14 text-primary border-primary/20",
  },
  accent: {
    ring: "ring-accent/18",
    glow: "shadow-[0_18px_60px_-20px] shadow-accent/30",
    chip: "bg-accent/14 text-accent border-accent/20",
  },
  warn: {
    ring: "ring-[hsl(var(--chart-3))]/18",
    glow: "shadow-[0_18px_60px_-20px] shadow-[hsl(var(--chart-3))]/30",
    chip: "bg-[hsl(var(--chart-3))]/14 text-[hsl(var(--chart-3))] border-[hsl(var(--chart-3))]/20",
  },
  danger: {
    ring: "ring-destructive/18",
    glow: "shadow-[0_18px_60px_-20px] shadow-destructive/30",
    chip: "bg-destructive/14 text-destructive border-destructive/20",
  },
};

export default function MetricCard({
  label,
  value,
  deltaPct,
  icon,
  tone = "primary",
  testId,
}: {
  label: string;
  value: ReactNode;
  deltaPct?: number | null;
  icon?: ReactNode;
  tone?: MetricTone;
  testId?: string;
}) {
  const delta = typeof deltaPct === "number" ? deltaPct : null;
  const up = delta !== null ? delta >= 0 : null;

  return (
    <div
      className={cn(
        "kpi-glow group relative overflow-hidden rounded-2xl border border-border/70 bg-gradient-to-b from-card/70 to-card/35 p-4",
        "transition-all duration-300 hover:-translate-y-0.5",
        "ring-1",
        toneStyles[tone].ring,
        toneStyles[tone].glow,
      )}
      data-testid={testId}
    >
      <div className="pointer-events-none absolute -left-12 -top-14 h-40 w-40 rounded-full bg-primary/10 blur-2xl opacity-60" />
      <div className="pointer-events-none absolute -right-14 -bottom-16 h-44 w-44 rounded-full bg-accent/10 blur-2xl opacity-60" />

      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            {label}
          </div>
          <div className="mt-2 text-balance text-2xl font-extrabold tracking-tight">
            {value}
          </div>

          {delta !== null && (
            <div className="mt-2 inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold">
              <span className={cn("inline-flex items-center gap-1", toneStyles[tone].chip)}>
                <span className="inline-flex items-center gap-1">
                  {up ? (
                    <ArrowUpRight className="h-3.5 w-3.5" />
                  ) : (
                    <ArrowDownRight className="h-3.5 w-3.5" />
                  )}
                  {Math.abs(delta).toFixed(1)}%
                </span>
              </span>
              <span className="text-muted-foreground">vs prev.</span>
            </div>
          )}
        </div>

        {icon ? (
          <div className="grid h-10 w-10 place-items-center rounded-xl border border-border/70 bg-card/60 text-muted-foreground transition-all duration-300 group-hover:text-foreground">
            {icon}
          </div>
        ) : null}
      </div>
    </div>
  );
}
