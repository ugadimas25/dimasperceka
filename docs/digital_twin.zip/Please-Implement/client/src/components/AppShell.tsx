import { PropsWithChildren } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Activity,
  Globe,
  Layers,
  ShieldAlert,
  Sparkles,
  Waves,
} from "lucide-react";

function NavItem({
  href,
  label,
  icon: Icon,
}: {
  href: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}) {
  const [loc] = useLocation();
  const active = loc === href;

  return (
    <Link
      href={href}
      className={cn(
        "group flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold transition-all duration-300",
        "hover:bg-muted/60 hover:text-foreground focus:outline-none focus-visible:ring-4 focus-visible:ring-primary/15",
        active
          ? "bg-muted/70 text-foreground shadow-sm"
          : "text-muted-foreground",
      )}
      data-testid={`nav-${label.toLowerCase().replace(/\s+/g, "-")}`}
    >
      <span
        className={cn(
          "grid h-9 w-9 place-items-center rounded-lg border border-border/60 bg-card/50 transition-all duration-300",
          active
            ? "border-primary/30 bg-gradient-to-b from-primary/15 to-transparent"
            : "group-hover:border-border group-hover:bg-card/70",
        )}
      >
        <Icon className={cn("h-4 w-4", active ? "text-primary" : "text-muted-foreground group-hover:text-foreground")} />
      </span>
      <span className="truncate">{label}</span>
    </Link>
  );
}

export default function AppShell({ children }: PropsWithChildren) {
  return (
    <div className="app-atmosphere min-h-screen">
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/40 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="absolute -inset-2 rounded-2xl bg-primary/20 blur-xl" />
              <div className="relative grid h-11 w-11 place-items-center rounded-2xl border border-border/60 bg-card/70 shadow-lg shadow-black/30">
                <Waves className="h-5 w-5 text-primary" />
              </div>
            </div>
            <div className="leading-tight">
              <div className="text-base font-bold tracking-tight">
                <span style={{ fontFamily: "var(--font-serif)" }}>Digital Twin</span>{" "}
                <span className="text-muted-foreground">· Climate‑Smart</span>
              </div>
              <div className="text-xs text-muted-foreground">
                Field intelligence, risk signals, and agronomic foresight
              </div>
            </div>
          </div>

          <div className="hidden items-center gap-2 md:flex">
            <Button
              variant="secondary"
              className="rounded-xl border border-border/70 bg-card/50 hover:bg-card/70"
              onClick={() => {
                window.location.href = "/digital-twin/climate-smart";
              }}
              data-testid="header-open-module"
            >
              <Sparkles className="mr-2 h-4 w-4" />
              Open Module
            </Button>
          </div>
        </div>
      </header>

      <div className="mx-auto flex max-w-[1600px] flex-col gap-6 px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
        <main className="w-full">{children}</main>
      </div>
    </div>
  );
}
